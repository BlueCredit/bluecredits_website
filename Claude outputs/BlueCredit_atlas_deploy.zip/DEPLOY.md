# BlueCredit Atlas — deployment guide

**Target:** https://atlas.bluecredits.org  
**Type:** static website (HTML, JS, data files). No server code to host.  
**Accounts and billing:** handled by the **BlueCredit Account** in the Marketplace app (bluecredits-core). Atlas has no database, no Supabase and no PayPal keys of its own.  
**Owner:** BlueCredit Inc. Contact: Nathan Wangusi, barasa@bluecredits.org

This site is separate from datacenterwaterleaks.com. Don't reuse anything from that site.

---

## 1. What's in this package

```
site/                       ← publish this folder as the website root
  index.html                the map (the whole app is in this one file)
  terms.html                Terms & Refund Policy
  404.html                  not-found page
  js/account.js             "Sign in with BlueCredit" + Pro unlock. CONFIG AT THE TOP
  data/                     datasets the map loads
  logo.png, favicon.svg     BlueCredit branding
  CNAME                     atlas.bluecredits.org (GitHub Pages custom domain)
  .nojekyll, .gitignore, README.md
admin/                      not published
  build_county_water_use.py rebuilds data/county_water_use_2015.json from USGS
DEPLOY.md                   this file
```

External libraries load from unpkg.com (Leaflet 1.9.4, esri-leaflet 3.0.10, Turf 6, leaflet-control-geocoder 4.0.0, topojson-client 3.1.0). Live data comes straight from public services in the browser: USGS, EPA, NOAA, USFWS, Esri and Google tiles. No API keys are needed for these.

## 2. Hosting (GitHub Pages), about 15 minutes

1. Create a new repository, for example `BlueCredit/bluecredit-atlas`. It can be private on a paid GitHub plan; Pages works either way.
2. Commit the **contents** of `site/` to the repository root on `main`. Keep `CNAME` and `.nojekyll`.
3. **Settings → Pages**: Source = *Deploy from a branch*, Branch = `main` / `(root)`. Custom domain = `atlas.bluecredits.org`. Turn on **Enforce HTTPS** once the certificate is issued.
4. **DNS** (wherever bluecredits.org is managed): add `CNAME  atlas  →  <github-org-or-user>.github.io`. Don't change the records for the main site.
5. Optional: **Settings → Pages → Verify domain** in the GitHub org, to prevent takeover.

**Optional:** to also catch people who type maps.bluecredits.org, add a 301 URL forward from `maps.bluecredits.org/*` to `https://atlas.bluecredits.org/$1` in your DNS provider. No extra files are needed.

Any static host works instead (Cloudflare Pages, Netlify, or nginx on the Contabo VPS). Serve `site/` as the web root with `404.html` as the not-found page.

## 3. Sign-in with the BlueCredit account

Atlas uses the same account as the Marketplace. The backend and portal changes are in **bluecredits-core** (see `docs/subscriptions.md` there):

- **Backend:** `/api/v1/sso/code`, `/exchange` and `/session`. Code is in `api/sso.py` and `modules/customer_portal/sso_module/`.
- **Portal:** the Account app at `/account`, including `/account/connect`, which sends people back to Atlas signed in.

How it works:

1. The visitor clicks **Sign in** on Atlas and goes to `https://marketplace.bluecredits.org/account/connect?app=atlas&return=<this page>`.
2. They sign in there if needed, with password, 2FA or Google, exactly as on the Marketplace.
3. They come back to Atlas with a one-time code, which Atlas swaps for their name, email and plan.

Atlas never sees passwords or portal tokens.

**Backend environment** (Contabo `prod.env`), in addition to the subscription settings:

```
SSO_ALLOWED_ORIGINS=atlas=https://atlas.bluecredits.org
```

To test against a staging copy of Atlas, add its address: `atlas=https://atlas.bluecredits.org|https://staging-atlas.example.org`.

**`site/js/account.js` settings** (top of the file):

| Setting | Value |
|---|---|
| `api` | `https://marketplace.bluecredits.org` (the backend that serves `/api/v1/sso/*`) |
| `account` | `https://marketplace.bluecredits.org/account` |
| `price` | `$29/month or $290/year` (text shown in the upgrade window; must match the PayPal plans) |

With `api` set to `''`, sign-in is off and every feature is open. That's safe for staging.

The backend's CORS already allows any origin with `Authorization` and `Content-Type` headers, so no CORS change is needed.

## 4. Plans (set in bluecredits-core)

| | Free | Pro | Enterprise |
|---|---|---|---|
| Price | $0 | $29/month or $290/year | From $149/month, quoted |
| Atlas | Map, free layers, Water Demand, popups, search | + reports (PDF/CSV), Pro layers, Print Map | + everything in Pro |
| Marketplace | Buy and retire credits, 1 site | 10 sites, AI bill upload, site analytics | Unlimited sites, 5 seats, bulk data |

Upgrades happen in the Account app (`/account/billing`). The upgrade window in Atlas links there with `?from=atlas&return=<page>`. After paying, **Back to Atlas** returns the visitor signed in with Pro.

Until the backend has `SUBSCRIPTIONS_ENFORCED=true`, every signed-in user gets Atlas Pro. Signed-out visitors are still asked to sign in for Pro features.

## 5. What Pro unlocks in Atlas

| Free | Pro and Enterprise |
|---|---|
| The map; all free layers and popups; search, "Your location" and the right-click menu | Site, location, basin, utility and Loudoun reports (PDF + CSV) |
| Water Demand: domestic and agricultural water use by county; industrial facilities by sector (EPA TRI); power plant cooling water (EIA actual); universities & colleges | Pro layers: Hotels, Projected Sites 2035, Wastewater Treatment Plants, Reclaimed Water, Recycled Water Lines, Streamgages (live), Groundwater Wells |
| Data centers, water projects, utilities, sewersheds, drought, streamflow vs. normal, watersheds, wetlands, rivers | Print Map (letter or tabloid PDF) |

Layers are marked `pro: true` in `LAYER_GROUPS` in `index.html`; change that flag to move a layer. The paywall runs in the browser: it stops ordinary users and records who pays, but it doesn't encrypt the data.

## 6. Test before announcing

1. **Backend and portal:** deploy the bluecredits-core changes first, with `SSO_ALLOWED_ORIGINS` set.
2. **Signed out:** open Atlas. The map works. The top right shows **Sign in** and the 9-dot apps menu, with Account, Home, Marketplace and Atlas.
3. **Sign-in prompt:** open a site report. The window asks you to sign in with BlueCredit.
4. **Sign in:** click **Sign in with BlueCredit**, sign in on the Marketplace, and you should land back on the same Atlas page with your name at the top right.
5. **Free user:** open a report. The upgrade window appears. Click **See plans and upgrade**, subscribe to Pro, then click **Back to Atlas**. The chip should show **PRO** and reports should open.
6. **Sign out:** your name → **Sign out of Atlas** signs out of Atlas only.

## 7. Data

| File | Contents | Source |
|---|---|---|
| `county_water_use_2015.json` | County boundaries plus 2015 withdrawals by sector (Mgal/d), population and irrigated acres (TopoJSON) | USGS, *Estimated Use of Water in the U.S., County-Level Data for 2015* (doi:10.5066/F7TB15V5); boundaries from U.S. Census via `us-atlas@3` |
| `im3_atlas.geojson`, `im3_projected.json` | Existing and projected data centers | PNNL IM3 (doi:10.57931/3017294, 10.57931/3020186) |
| `wateruse.csv`, `wateroffsets.csv`, `wateruse_loudoun.csv`, `waterreclaimed.csv` | FOIA/utility water use, water projects, Loudoun aggregates and reclaimed-water records | public-records responses and utility data compiled by BlueCredit |
| `cwns_wastewater.json` | Wastewater treatment plants | U.S. EPA 2022 CWNS |
| `tri_facilities_2024.json` | 21,482 industrial facilities with sector (grouped into 9 categories), pounds of chemicals discharged to water, sent to sewage plants and released in total | U.S. EPA Toxics Release Inventory 2024 (public domain) |
| `eia_cooling_2024.json` | 737 power plants: actual 2024 cooling-water withdrawal and consumption (million gallons), cooling type, water source | U.S. EIA thermoelectric cooling water data 2024 + EIA *Power Plants in the U.S.* locations (public domain) |
| `universities.json` | 6,511 active colleges and universities: enrollment, dorm capacity, employees | DHS HIFLD *Colleges and Universities* (NCES IPEDS), public domain |
| `hotels.json` | 20,936 hotels, open and in the pipeline: rooms, brand, class, status, year built (contact names and phones removed) | Lodging Econometrics (licensed) |

**Hotels licence:** `hotels.json` is a static file, so anyone who finds its URL can download it, even though the layer is Pro-only on the map. If the Lodging Econometrics licence doesn't allow public redistribution, serve this file from the backend to signed-in Pro users instead, or show hotels by county only.

**Facility water estimates** (planning-level, shown as estimates in the popups):
- **Hotels:** rooms × 33,500 gal/yr, with a typical range of half to double.
- **Universities:** dorm beds × 82 gal/day × 270 days, plus employees × 11,200 gal/yr.
- **Sources:** WaterSense & ENERGY STAR, *U.S. Water Use Intensity by Property Type: Technical Reference* (June 2023), and EPA WaterSense (82 gal/person/day, from USGS 2015).

To rebuild the county water-use file (for example if USGS publishes an update):

```
npm install us-atlas@3
python admin/build_county_water_use.py usco2015v2.0.csv node_modules/us-atlas/counties-10m.json site/data/county_water_use_2015.json
```

Water Demand categories:
- **Domestic**: self-supplied plus public-supply deliveries to homes (`DO-WDelv`).
- **Industrial**: industrial self-supplied plus mining (`IN-Wtotl` + `MI-Wtotl`).
- **Agricultural**: irrigation, livestock and aquaculture (`IR-WFrTo` + `LI-WFrTo` + `AQ-Wtotl`).
- **Power plant cooling**: thermoelectric (`PT-Wtotl`).

Only one sector map shows at a time. 2015 is the latest USGS release that covers every sector; USGS's newer model estimates cover only public supply, irrigation and thermoelectric.

## 8. Maintenance notes

- Everything is in `index.html`. Search for these names:
  - `LAYER_GROUPS`: the layer panel.
  - `WD`: Water Demand layers; `brWaterDemandSection`: report section 7.
  - `SG`: streamgages.
  - `GW`: groundwater.
  - `NWM`: NOAA streamflow.
  - `openSiteReport` and `openAreaReport`: reports.
  - `pmBuildTitleBlock`: the print map.
- App launcher (9-dot menu, top right): `BC_APPS` near the end of `index.html`. Order: Account, Home, Marketplace, Atlas. Account and Marketplace links follow `BC_ACCOUNT.account`.
- Sign-in: `js/account.js`. It keeps the plan in the browser (`localStorage` key `bc_atlas_session`) and refreshes it every 10 minutes.
- Industry layers: `IND` in `index.html` (TRI sectors are grouped in `data/tri_facilities_2024.json` → `groups`). Refresh yearly from the TRI basic data file and EIA thermoelectric cooling water data.
- Sewersheds load live from EPA's National Sewershed feature service (`SEWER.url` in `index.html`), from zoom 8 in.
- Live services can change. If a layer goes blank, check the browser console, then the service URL in the code.
- Pin library versions as they are now. `leaflet-control-geocoder` must stay on 4.0.0.
