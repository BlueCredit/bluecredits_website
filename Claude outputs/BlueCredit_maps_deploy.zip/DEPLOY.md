# BlueCredit Water Map — deployment guide

**Target:** https://maps.bluecredits.org  
**Type:** static website (HTML, JS, data files). There is no server code to host; sign-in and payments run on Supabase and PayPal.  
**Owner:** BlueCredit Inc. Contact: Nathan Wangusi, barasa@bluecredits.org

This site is **completely separate** from datacenterwaterleaks.com. It needs its own GitHub repository, Supabase project and PayPal app and plans. Do not reuse any keys, projects or plans from that site.

---

## 1. What's in this package

```
site/                       ← publish this folder as the website root
  index.html                the map (the whole app is in this one file)
  terms.html                Terms & Refund Policy (linked from the map and checkout)
  404.html                  not-found page
  js/account.js             sign-in (Supabase) + Pro subscription (PayPal). CONFIG AT THE TOP
  data/                     datasets the map loads
  logo.png, favicon.svg     BlueCredit branding
  CNAME                     maps.bluecredits.org (GitHub Pages custom domain)
  .nojekyll, .gitignore, README.md
admin/                      setup files. DO NOT publish
  supabase_setup.sql        tables for members and the report log (run first)
  pro_setup.sql             Pro subscription tables and functions (run second)
  paypal_function.ts        Supabase Edge Function: PayPal activation, cancellation, webhooks
  supabase_email_template.html   branded sign-in email
  build_county_water_use.py rebuilds data/county_water_use_2015.json from USGS
DEPLOY.md                   this file
```

External libraries load from unpkg.com (Leaflet 1.9.4, esri-leaflet 3.0.10, Turf, leaflet-control-geocoder 4.0.0, topojson-client 3.1.0) and cdn.jsdelivr.net (supabase-js 2). Live data comes straight from public services in the browser: USGS, EPA, NOAA, USFWS, Esri and Google tiles. No API keys are needed for these.

## 2. Hosting (GitHub Pages), about 15 minutes

1. Create a new repository, for example `BlueCredit/bluecredit-maps`. It can be private on a paid GitHub plan; Pages works either way.
2. Commit the **contents** of `site/` to the repository root on `main`. Keep `CNAME` and `.nojekyll`.
3. **Settings → Pages**: Source = *Deploy from a branch*, Branch = `main` / `(root)`. Custom domain = `maps.bluecredits.org`. Turn on **Enforce HTTPS** once the certificate is issued, which takes minutes to an hour.
4. **DNS** (wherever bluecredits.org is managed): add
   `CNAME  maps  →  <github-org-or-user>.github.io`
   Don't change the records for the main bluecredits.org site.
5. Optional: **Settings → Pages → Verify domain** in the GitHub org, to prevent takeover.

Any static host works instead (Cloudflare Pages, Netlify, S3 + CloudFront, or nginx on the existing Contabo VPS). Serve `site/` as the web root, with `404.html` as the not-found page.

> If the final domain is different, change `CNAME` and search-and-replace `maps.bluecredits.org` in `index.html`, `terms.html`, `admin/supabase_email_template.html` and `admin/paypal_function.ts`.

## 3. Supabase (sign-in and Pro records), about 25 minutes

1. Create a **new** Supabase project, for example "bluecredit-maps", in a US region.
2. **SQL Editor**: run `admin/supabase_setup.sql`, then `admin/pro_setup.sql`.
3. **Authentication → URL Configuration**
   - Site URL: `https://maps.bluecredits.org`
   - Redirect URLs: `https://maps.bluecredits.org/**`, plus your staging URL with `/**` if you have one.
4. **Email sending.** This is required: Supabase's built-in mailer only reaches team members.
   - Set up Resend, Brevo or the existing Zoho account with the domain bluecredits.org and its DNS records (SPF/DKIM).
   - **Authentication → Emails → SMTP Settings**: sender `maps@bluecredits.org` (or `noreply@`), name `BlueCredit`.
   - **Authentication → Rate Limits**: raise emails per hour to about 100.
5. **Authentication → Emails → Templates**: paste `admin/supabase_email_template.html` into **Magic Link** and **Confirm signup**. Subject: `Your BlueCredit sign-in code: {{ .Token }}`. Set **Providers → Email → Email OTP length** to 6.
6. **Project Settings → API**: copy the **Project URL** and the **anon / publishable** key for step 5.

## 4. PayPal (Pro subscription), about 25 minutes

1. **PayPal business account:** use BlueCredit's. Set the business display name customers see to "BlueCredit".
2. **Plans** (paypal.com/billing/plans):
   - Create product "BlueCredit Water Map Pro" (Service).
   - Create a Monthly and a Yearly plan at the prices Nathan chooses, with no trial and no setup fee.
   - Turn both **ON** and copy both Plan IDs (`P-…`).
3. **API app** (developer.paypal.com → Apps & Credentials → **Live** → Create App, type Merchant, e.g. "BlueCredit Maps"):
   - The **Client ID** is public and goes in `account.js`.
   - The **Secret** is private and goes only in Supabase secrets.
4. **Edge Function** (Supabase → Edge Functions → Deploy new function → Via Editor):
   - Name it `paypal`, paste `admin/paypal_function.ts` and deploy.
   - Turn **JWT verification OFF** for this function. PayPal's webhook calls carry no Supabase token; the code verifies users and PayPal signatures itself.
5. **Edge Function secrets:**
   - `PAYPAL_CLIENT_ID` = the Live Client ID
   - `PAYPAL_SECRET` = the Live Secret
   - `PAYPAL_PLAN_IDS` = `P-monthly,P-yearly`
   - `PAYPAL_ENV` = `live` (use `sandbox` with sandbox credentials for a dry run)
   - `PAYPAL_WEBHOOK_ID` = from the next step
6. **Webhook** (PayPal app → Live Webhooks → Add):
   - URL: `https://<project-ref>.supabase.co/functions/v1/paypal`
   - Events: `BILLING.SUBSCRIPTION.ACTIVATED`, `.UPDATED`, `.CANCELLED`, `.SUSPENDED`, `.EXPIRED`, `.RE-ACTIVATED`, `PAYMENT.SALE.COMPLETED`
   - Copy the Webhook ID into `PAYPAL_WEBHOOK_ID`.

## 5. Configure the site: `site/js/account.js`

Near the top, replace every `PASTE_…` value:

| Setting | Value |
|---|---|
| `url` | Supabase Project URL (`https://<ref>.supabase.co`) |
| `anonKey` | Supabase **anon / publishable** key |
| `paypal.clientId` | PayPal **Live Client ID** |
| `paypal.plans[0].id` / `.price` | Monthly Plan ID and label, e.g. `$X / month` |
| `paypal.plans[1].id` / `.price` | Yearly Plan ID and label |
| `paypal.fn` | `paypal` (the Edge Function name) |
| `contact` | support email shown after checkout problems |

**Never** put the Supabase `service_role` / secret key or the PayPal Secret in any website file. Only the Client ID and Plan IDs are public.

While any value still says `PASTE_`, sign-in is switched off and every feature is open. The site works, but nothing is paywalled. That's safe for a soft launch or staging.

Optional: Google Analytics 4. Set `window.GA_ID = 'G-…'` in the `<head>` of `index.html`.

## 6. What Pro unlocks

| Free (no sign-in) | Pro (monthly or yearly subscription) |
|---|---|
| The map; all free layers and popups; search, "Your location" and the right-click menu | Site, location, basin, utility and Loudoun reports (PDF + CSV) |
| Water Demand: domestic, industrial, agricultural and power plant water use by county | Pro layers: Projected Sites 2035, Wastewater Treatment Plants, Reclaimed Water, Recycled Water Lines, Streamgages (live), Groundwater Wells |
| Data centers, water projects, utilities, drought, streamflow vs. normal, watersheds, wetlands, rivers | Print Map (letter or tabloid PDF) |

Layers are marked with `pro: true` in `LAYER_GROUPS` in `index.html`; change that flag to move a layer. The paywall runs in the browser: it stops ordinary users and records who pays, but it does not encrypt the data.

## 7. Test before announcing

1. Open the site and check that the BlueCredit logo, layers, search, reports and print all work. With placeholders still in place, everything is open.
2. After step 5, sign in with an email code, then open a site report. The upgrade window should appear.
3. Subscribe with a real card on the Monthly plan. The report should open and the account chip should show **PRO**.
4. In Supabase SQL Editor, `select * from pro_supporters;` should show the row.
5. In the account menu, choose **Cancel subscription**. Status should become CANCELLED, with access until the paid-through date.
6. Refund the test payment in PayPal (Activity → payment → Refund).

## 8. Data

| File | Contents | Source |
|---|---|---|
| `county_water_use_2015.json` | County boundaries plus 2015 withdrawals by sector (Mgal/d), population and irrigated acres (TopoJSON) | USGS, *Estimated Use of Water in the U.S., County-Level Data for 2015* (doi:10.5066/F7TB15V5); boundaries from U.S. Census via `us-atlas@3` |
| `im3_atlas.geojson`, `im3_projected.json` | Existing and projected data centers | PNNL IM3 (doi:10.57931/3017294, 10.57931/3020186) |
| `wateruse.csv`, `wateroffsets.csv`, `wateruse_loudoun.csv`, `waterreclaimed.csv` | FOIA/utility water use, water projects, Loudoun aggregates and reclaimed-water records | public-records responses and utility data compiled by BlueCredit |
| `cwns_wastewater.json` | Wastewater treatment plants | U.S. EPA 2022 CWNS |

To rebuild the county water-use file (for example if USGS publishes an update):

```
npm install us-atlas@3
python admin/build_county_water_use.py usco2015v2.0.csv node_modules/us-atlas/counties-10m.json site/data/county_water_use_2015.json
```

Water Demand categories:
- **Domestic**: self-supplied plus public-supply deliveries to homes (`DO-WDelv`).
- **Industrial**: industrial self-supplied plus mining (`IN-Wtotl` + `MI-Wtotl`).
- **Agricultural**: irrigation, livestock and aquaculture (`IR-WFrTo` + `LI-WFrTo` + `AQ-Wtotl`).
- **Power plant cooling**: thermoelectric (`PT-Wtotl`).

Only one sector map shows at a time. 2015 is the latest USGS release that covers every sector; USGS's newer model estimates cover only public supply, irrigation and thermoelectric.

## 9. Maintenance notes

- Everything is in `index.html`. Search for these names:
  - `LAYER_GROUPS`: the layer panel.
  - `WD`: Water Demand layers; `brWaterDemandSection`: report section 7.
  - `SG`: streamgages.
  - `GW`: groundwater.
  - `NWM`: NOAA streamflow.
  - `openSiteReport` and `openAreaReport`: reports.
  - `pmBuildTitleBlock`: the print map.
- Live services can change. If a layer goes blank, check the browser console, then the service URL in the code.
- Pin library versions as they are now. `leaflet-control-geocoder` must stay on 4.0.0.
