-- BlueCredit Water Map — Pro (PayPal) additions. Run AFTER supabase_setup.sql in the maps Supabase project.
-- Supabase → SQL Editor → New query → paste → Run. Safe to run more than once.

alter table public.members
    add column if not exists plan text not null default 'free',       -- 'free' | 'pro'
    add column if not exists plan_status text,                        -- PayPal status: ACTIVE, CANCELLED, SUSPENDED, EXPIRED
    add column if not exists plan_expires timestamptz,                -- Pro access runs until this time
    add column if not exists paypal_subscription_id text,
    add column if not exists paypal_plan_id text,
    add column if not exists plan_updated timestamptz;

-- Members can already read their own row (policy from supabase_setup.sql). There is NO update policy,
-- so only the PayPal function (running with the service key) can change someone's plan.

-- Admin view: who supports, which plan, until when
create or replace view public.pro_supporters with (security_invoker = true) as
select email, organization, plan, plan_status, plan_expires, paypal_plan_id, paypal_subscription_id, plan_updated
  from public.members
 where plan = 'pro' or paypal_subscription_id is not null
 order by plan_updated desc nulls last;
revoke all on public.pro_supporters from anon, authenticated;

-- Handy: select * from pro_supporters;
