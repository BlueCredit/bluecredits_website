-- BlueCredit Water Map — Supabase setup (run first, in a NEW Supabase project for maps.bluecredits.org)
-- Paste this whole file into Supabase → SQL Editor → New query → Run. Safe to run more than once.
--
-- Creates:
--   members      one row per signed-in person (email, organization, newsletter opt-in, first/last seen, report count)
--   report_log   one row per report opened or downloaded (who, which report, which area, format)
--   two admin views: report_activity (latest activity) and report_totals (counts by person)
-- Visitors can only ADD their own report events. Nobody can read these tables through the website;
-- you read them in the Supabase dashboard (Table Editor or SQL Editor), which bypasses these rules.

-- ── members ──
create table if not exists public.members (
    user_id      uuid primary key references auth.users(id) on delete cascade,
    email        text not null,
    organization text,
    newsletter   boolean default false,
    signup_page  text,
    first_seen   timestamptz not null default now(),
    last_seen    timestamptz not null default now(),
    report_count integer not null default 0
);
alter table public.members enable row level security;
drop policy if exists "members: read own row" on public.members;
create policy "members: read own row" on public.members for select to authenticated using (user_id = auth.uid());

-- create the member row automatically when someone signs up (organization + newsletter come from the sign-in form)
create or replace function public.dcwl_handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
    insert into public.members (user_id, email, organization, newsletter, signup_page)
    values (new.id, new.email,
            nullif(new.raw_user_meta_data->>'organization', ''),
            coalesce((new.raw_user_meta_data->>'newsletter')::boolean, false),
            new.raw_user_meta_data->>'signup_page')
    on conflict (user_id) do nothing;
    return new;
end $$;
drop trigger if exists dcwl_on_auth_user_created on auth.users;
create trigger dcwl_on_auth_user_created after insert on auth.users
    for each row execute function public.dcwl_handle_new_user();

-- ── report_log ──
create table if not exists public.report_log (
    id          bigint generated always as identity primary key,
    created_at  timestamptz not null default now(),
    user_id     uuid not null default auth.uid() references auth.users(id) on delete cascade,
    email       text,
    event       text not null,        -- basin_report_open, utility_report_download, site_report_open, …
    report_type text,                 -- basin | utility | site
    format      text,                 -- view | pdf | csv
    area_id     text,                 -- HUC-8 or PWSID
    area_name   text,
    operator    text,                 -- site reports
    dataset     text,                 -- site reports: FOIA or IM3 Atlas
    page        text
);
create index if not exists report_log_created_idx on public.report_log (created_at desc);
alter table public.report_log enable row level security;
drop policy if exists "report_log: add own events" on public.report_log;
create policy "report_log: add own events" on public.report_log for insert to authenticated
    with check (user_id = auth.uid());
-- (no select/update/delete policies: the website can't read or change the log)

-- the email is taken from the signed-in account, not from the browser; also bumps the member's counters
create or replace function public.dcwl_report_log_fill() returns trigger
language plpgsql security definer set search_path = public as $$
begin
    new.user_id := auth.uid();
    new.email   := (select email from auth.users where id = auth.uid());
    update public.members
       set last_seen = now(),
           report_count = report_count + case when new.event like '%\_open' then 1 else 0 end
     where user_id = new.user_id;
    return new;
end $$;
drop trigger if exists dcwl_report_log_fill on public.report_log;
create trigger dcwl_report_log_fill before insert on public.report_log
    for each row execute function public.dcwl_report_log_fill();

-- ── admin views (dashboard only) ──
create or replace view public.report_activity with (security_invoker = true) as
select r.created_at, r.email, m.organization, r.report_type, r.format, r.area_name, r.area_id, r.operator, r.dataset
  from public.report_log r left join public.members m on m.user_id = r.user_id
 order by r.created_at desc;

create or replace view public.report_totals with (security_invoker = true) as
select m.email, m.organization, m.newsletter, m.first_seen, m.last_seen,
       count(*) filter (where r.format = 'view')                     as reports_opened,
       count(*) filter (where r.format = 'pdf')                      as pdf_downloads,
       count(*) filter (where r.format = 'csv')                      as csv_downloads,
       count(*) filter (where r.report_type = 'basin' and r.format = 'view')   as basin,
       count(*) filter (where r.report_type = 'utility' and r.format = 'view') as utility,
       count(*) filter (where r.report_type = 'site' and r.format = 'view')    as site
  from public.members m left join public.report_log r on r.user_id = m.user_id
 group by m.user_id, m.email, m.organization, m.newsletter, m.first_seen, m.last_seen
 order by m.last_seen desc;

revoke all on public.report_activity, public.report_totals from anon, authenticated;

-- Handy queries (run in SQL Editor):
--   select * from report_activity limit 100;                       -- latest reports, who made them
--   select * from report_totals;                                   -- per-person totals
--   select area_name, count(*) from report_log where format='view' group by 1 order by 2 desc;   -- most-requested areas
--   select email, organization from members where newsletter;      -- newsletter opt-ins
