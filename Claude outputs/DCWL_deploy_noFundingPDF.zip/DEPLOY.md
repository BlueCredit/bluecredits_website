# Data Center Water Leaks — deployment package

## What's in this package
| Folder | Upload to GitHub? | Contents |
|---|---|---|
| `site/` | **Yes — this is the whole website** | Pages, scripts, logo, public PDFs/downloads, and `data/` |
| `admin/` | **No — keep private** | Supabase SQL, PayPal function, email template, setup guides, architecture plan |
| `archive/` | No | Old/unused files removed from the site (`arc/`, `wateruse_agg.geojson`, `loudoun_zone.geojson`) |

## What changed from the current repo
- Data files moved into `site/data/` (all page code updated to match; tested with the real CSVs).
- `map.html` + `account.js` are the latest (Pro Supporter paywall for reports — stays on free sign-in until PayPal IDs are added).
- KMZ download links fixed (`../usdatacentermap.kmz` → `usdatacentermap.kmz`).
- Removed from the public site: `arc/` (old copies), two unused GeoJSON files, and `blueatlas_architecture.md` (an internal plan that was publicly readable at datacenterwaterleaks.com/blueatlas_architecture.md).
- Added `.nojekyll` (faster GitHub Pages builds), `.venv/` to `.gitignore`, and a new `README.md`.
- Folders: `pages/` (all pages except `index.html`), `js/` (scripts), `data/` (data + KMZ), `docs/` (PDFs and Word files). `index.html` stays at the root.
- `404.html` forwards old links (e.g. /map.html, /foia_opinion.pdf, /usdatacentermap.kmz) to their new locations, so links already shared keep working.
- Supabase → Authentication → URL Configuration → Redirect URLs must include `https://www.datacenterwaterleaks.com/**` and `https://datacenterwaterleaks.com/**` (with the `/**`), so sign-in links from /pages/... work.

## Deploy (GitHub Desktop or command line)
1. Open your local `blueatlas` folder (the one with the `.git` folder).
2. Delete everything in it **except** the hidden `.git` folder (and `.venv` if you use it — it's ignored now).
3. Copy the **contents** of `site/` (including the hidden `.gitignore` and `.nojekyll`) into `blueatlas`.
4. Commit ("Reorganize site; data folder; Pro Supporter") and push.
   Command line:
   ```
   cd blueatlas
   git add -A
   git commit -m "Reorganize site: data folder, cleanup, Pro Supporter"
   git push
   ```
5. Wait 1–2 minutes, then check: datacenterwaterleaks.com — counters show numbers; Water Map loads dots; Usage/Offsets charts load.

