# Sign-in setup (Supabase) — about 20 minutes

The map stays public. Signing in (free, email code, no password) unlocks basin, utility, site and Loudoun reports and their CSV downloads. Every report opened or downloaded is logged with the person's email and organization.

## 1. Create the tables (2 min)
Supabase → **SQL Editor** → New query → paste all of `supabase_setup.sql` → **Run**.

## 2. Add your public key to `account.js` (1 min)
Supabase → **Project Settings → API Keys** → copy the **anon public** key (or the **publishable** key, `sb_publishable_…`).
Open `account.js` and replace `PASTE_YOUR_ANON_OR_PUBLISHABLE_KEY_HERE`.
This key is designed to be public. **Never** use the `service_role` / secret key.
Until the key is added, reports stay open to everyone, so the site keeps working either way.

## 3. Allow your website address (1 min)
Supabase → **Authentication → URL Configuration**
- Site URL: `https://datacenterwaterleaks.com`
- Redirect URLs: add `https://datacenterwaterleaks.com/**`

## 4. Set up email sending (10–15 min) — required
Supabase's built-in email only sends to your own team's addresses, a few per hour. It is not meant for real users. Connect a free sender:
1. Create a free account at **resend.com** (3,000 emails/month) or **brevo.com**.
2. Add the domain `datacenterwaterleaks.com` there and add the DNS records it gives you where your domain is managed. This is the same place you pointed the domain at GitHub Pages. It's OK to leave the GitHub Pages records unchanged.
3. Supabase → **Authentication → Emails → SMTP Settings** → enable custom SMTP and enter the host, port, username and password from Resend or Brevo. Sender: `reports@datacenterwaterleaks.com`, name `Data Center Water Leaks`.
4. Supabase → **Authentication → Rate Limits**: raise "emails per hour" (e.g. 100).

## 5. Branded email (2 min)
Supabase → **Authentication → Emails → Templates** → paste `supabase_email_template.html` into both **Magic Link** and **Confirm signup**. Subject: `Your Data Center Water Leaks sign-in code: {{ .Token }}`.
If the code is more than 6 digits, set **Authentication → Providers → Email → Email OTP length** to 6.

## 6. Upload to GitHub
Add `account.js` and `logo.png` next to `map.html`, plus the updated `map.html`. Don't upload the `.sql`, `.md` or template files; they're only for setup.

## Seeing who made reports
Supabase → **SQL Editor**:
```sql
select * from report_activity limit 100;   -- latest reports: when, who, organization, which area
select * from report_totals;               -- per person: reports opened, PDFs, CSVs, by type
select email, organization from members where newsletter;   -- newsletter opt-ins
```
Also visible under **Table Editor → members / report_log**. Everyone who signs in is also listed under **Authentication → Users**.

## Notes
- Newsletter opt-ins at sign-in also go to your Google Form, with the source "Map sign-in".
- This setup (Option A) gates reports for sign-up and tracking. The FOIA CSVs are still public files on GitHub. To protect the data itself later, the tables move into Supabase (Option B).
- Add a privacy policy page saying you collect email and organization to provide reports and, with consent, the newsletter.
