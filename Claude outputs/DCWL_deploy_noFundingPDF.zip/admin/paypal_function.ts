// Data Center Water Leaks — Supabase Edge Function "paypal"
// Two jobs:
//   1. The website calls it right after a PayPal subscription is approved → it checks the subscription with PayPal
//      and marks the signed-in member as Pro.
//   2. PayPal calls it (webhook) when a subscription renews, is cancelled, suspended or expires → keeps the plan current.
//
// Secrets to set in Supabase → Edge Functions → Secrets:
//   PAYPAL_CLIENT_ID, PAYPAL_SECRET, PAYPAL_WEBHOOK_ID, PAYPAL_PLAN_IDS (comma-separated P-... ids), PAYPAL_ENV (live | sandbox)
// SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are provided automatically.
// Deploy with "Verify JWT" turned OFF (PayPal's webhook calls carry no Supabase token; the code checks users itself).

import { createClient } from "npm:@supabase/supabase-js@2";

const PP = Deno.env.get("PAYPAL_ENV") === "sandbox" ? "https://api-m.sandbox.paypal.com" : "https://api-m.paypal.com";
const CLIENT_ID = Deno.env.get("PAYPAL_CLIENT_ID") ?? "";
const SECRET = Deno.env.get("PAYPAL_SECRET") ?? "";
const WEBHOOK_ID = Deno.env.get("PAYPAL_WEBHOOK_ID") ?? "";
const PLAN_IDS = (Deno.env.get("PAYPAL_PLAN_IDS") ?? "").split(",").map((s) => s.trim()).filter(Boolean);
const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (b: unknown, status = 200) => new Response(JSON.stringify(b), { status, headers: { ...cors, "Content-Type": "application/json" } });

async function ppToken(): Promise<string> {
  const r = await fetch(`${PP}/v1/oauth2/token`, {
    method: "POST",
    headers: { Authorization: "Basic " + btoa(`${CLIENT_ID}:${SECRET}`), "Content-Type": "application/x-www-form-urlencoded" },
    body: "grant_type=client_credentials",
  });
  if (!r.ok) throw new Error(`PayPal auth failed (${r.status})`);
  return (await r.json()).access_token;
}

async function getSubscription(id: string, token: string) {
  const r = await fetch(`${PP}/v1/billing/subscriptions/${encodeURIComponent(id)}`, { headers: { Authorization: `Bearer ${token}` } });
  if (!r.ok) throw new Error(`Subscription lookup failed (${r.status})`);
  return await r.json();
}

// Write the member's plan from a PayPal subscription object
async function applySubscription(sub: any) {
  const userId = sub.custom_id;
  if (!userId) return "no custom_id";
  if (PLAN_IDS.length && !PLAN_IDS.includes(sub.plan_id)) return "plan not recognised";
  const status: string = sub.status; // APPROVAL_PENDING, APPROVED, ACTIVE, SUSPENDED, CANCELLED, EXPIRED
  const next = sub.billing_info?.next_billing_time;
  const update: Record<string, unknown> = {
    plan_status: status, paypal_subscription_id: sub.id, paypal_plan_id: sub.plan_id, plan_updated: new Date().toISOString(),
  };
  if (status === "ACTIVE") {
    update.plan = "pro";
    // access until the next billing date, plus 3 days' grace for payment retries
    update.plan_expires = next ? new Date(Date.parse(next) + 3 * 864e5).toISOString() : null;
  } else if (status === "CANCELLED") {
    // keep "pro" until the already-paid period ends (plan_expires is left as it was)
    update.plan = "pro";
  } else if (status === "SUSPENDED" || status === "EXPIRED") {
    update.plan = "free";
    update.plan_expires = new Date().toISOString();
  }
  const { error } = await admin.from("members").update(update).eq("user_id", userId);
  if (error) throw new Error(error.message);
  return "ok";
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const body = await req.json();

    // ── 1. PayPal webhook ──
    if (req.headers.get("paypal-transmission-id")) {
      const token = await ppToken();
      const v = await fetch(`${PP}/v1/notifications/verify-webhook-signature`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          auth_algo: req.headers.get("paypal-auth-algo"),
          cert_url: req.headers.get("paypal-cert-url"),
          transmission_id: req.headers.get("paypal-transmission-id"),
          transmission_sig: req.headers.get("paypal-transmission-sig"),
          transmission_time: req.headers.get("paypal-transmission-time"),
          webhook_id: WEBHOOK_ID,
          webhook_event: body,
        }),
      });
      if ((await v.json()).verification_status !== "SUCCESS") return json({ error: "bad signature" }, 400);
      const type: string = body.event_type ?? "";
      const res = body.resource ?? {};
      const subId = type.startsWith("BILLING.SUBSCRIPTION") ? res.id : res.billing_agreement_id; // PAYMENT.SALE.* carry billing_agreement_id
      if (subId) await applySubscription(await getSubscription(subId, token));
      return json({ received: true });
    }

    // ── 2. Website, right after checkout ──
    const jwt = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "");
    const { data: { user } } = await admin.auth.getUser(jwt);
    if (!user) return json({ error: "not signed in" }, 401);
    // ── 3. Website "Cancel subscription" button ──
    if (body.action === "cancel") {
      const { data: m } = await admin.from("members").select("paypal_subscription_id").eq("user_id", user.id).single();
      if (!m?.paypal_subscription_id) return json({ error: "no subscription on this account" }, 404);
      const token = await ppToken();
      const c = await fetch(`${PP}/v1/billing/subscriptions/${encodeURIComponent(m.paypal_subscription_id)}/cancel`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ reason: "Cancelled by subscriber on datacenterwaterleaks.com" }),
      });
      if (!c.ok && c.status !== 422) throw new Error(`PayPal cancel failed (${c.status})`); // 422 = already cancelled
      await applySubscription(await getSubscription(m.paypal_subscription_id, token));
      const { data } = await admin.from("members").select("plan, plan_expires, plan_status").eq("user_id", user.id).single();
      return json(data ?? {});
    }

    if (!body.subscriptionID) return json({ error: "missing subscriptionID" }, 400);
    const token = await ppToken();
    const sub = await getSubscription(body.subscriptionID, token);
    if (sub.custom_id !== user.id) return json({ error: "subscription belongs to another account" }, 403);
    await applySubscription(sub);
    const { data } = await admin.from("members").select("plan, plan_expires, plan_status").eq("user_id", user.id).single();
    return json(data ?? {});
  } catch (e) {
    return json({ error: String((e as Error).message ?? e) }, 500);
  }
});
