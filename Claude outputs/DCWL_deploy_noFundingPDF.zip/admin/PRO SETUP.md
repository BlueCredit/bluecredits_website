# Pro Supporter setup (PayPal subscriptions) — about 30 minutes

Site, basin, utility and Loudoun reports become a Pro Supporter feature. Everything else stays as it is: map, layers and popups are free; print map, explorer tabs and KMZ need a free sign-in.
Until step 5 is done, the site behaves exactly as now (reports need only a free sign-in), so it is safe to upload `account.js` and `map.html` first.

## 1. PayPal account (5 min)
- Confirm your email (the purple banner in PayPal). Payments are blocked until you do.
- Optional: **Account Settings → Business information** → set the name customers see to "Data Center Water Leaks". Checkout already shows this name, but receipts and card statements use your PayPal business name unless you change it.

## 2. Create the subscription plans (10 min)
PayPal → **Pay & Get Paid → Subscriptions → Subscription plans → Create plan** (or at paypal.com/billing/plans):
- Product: "Data Center Water Leaks — Pro Supporter", type Digital / Service.
- Plan 1: **Monthly**, fixed price **$7**, billed every 1 month, no end date.
- Plan 2: **Yearly**, fixed price **$84**, billed every 12 months, no end date.
- Turn the plans **ON**, then copy each **Plan ID** (starts with `P-`).

## 3. Get your API keys (5 min)
developer.paypal.com → log in → **Apps & Credentials** → switch to **Live** → **Create App** (name it "DCWL website", type Merchant).
Copy the **Client ID** (public) and the **Secret** (private — it only goes into Supabase, never the website or chat).

## 4. Supabase: database + function (10 min)
1. **SQL Editor** → paste all of `pro_setup.sql` → Run.
2. **Edge Functions → Deploy a new function → Via Editor**. Your function is named `bright-worker`, paste all of `paypal_function.ts`, and deploy.
   In the function's **Details / Settings**, turn **"Verify JWT with legacy secret" / "Enforce JWT verification" OFF**. PayPal's calls don't carry a Supabase token; the code checks users and PayPal signatures itself.
3. **Edge Functions → Secrets** → add:
   - `PAYPAL_CLIENT_ID` = your Live Client ID
   - `PAYPAL_SECRET` = your Live Secret
   - `PAYPAL_PLAN_IDS` = `P-monthly,P-yearly` (both IDs, comma-separated)
   - `PAYPAL_ENV` = `live`
   - `PAYPAL_WEBHOOK_ID` = (from step 4.4)
4. Back in developer.paypal.com → your app → **Live Webhooks → Add Webhook**:
   - URL: `https://efwovptwhousctqakgfy.supabase.co/functions/v1/bright-worker`
   - Events: `BILLING.SUBSCRIPTION.ACTIVATED`, `.UPDATED`, `.CANCELLED`, `.SUSPENDED`, `.EXPIRED`, `.RE-ACTIVATED`, and `PAYMENT.SALE.COMPLETED`
   - Save, copy the **Webhook ID**, and put it in the `PAYPAL_WEBHOOK_ID` secret.

## 5. Turn it on in the website (2 min)
Open `account.js`, find the `paypal:` block near the top, and replace:
- `PASTE_PAYPAL_CLIENT_ID` → your Live **Client ID**
- `PASTE_MONTHLY_PLAN_ID` / `PASTE_YEARLY_PLAN_ID` → the two Plan IDs
Upload `account.js` to GitHub. (Or send me the Client ID and Plan IDs — never the Secret — and I'll do it.)

## 6. Test with a real $7 payment
Sign in on the map → open a site report → the "Become a Pro Supporter" window appears → subscribe with PayPal → the report opens and your email shows a PRO badge.
Then refund yourself in PayPal (Activity → the payment → Refund) and cancel the subscription.
Check: Supabase SQL Editor → `select * from pro_supporters;`

## How cancellations work
Cancel in PayPal → the member keeps Pro until the end of the period they paid for, then drops to free. Failed payments (suspended) end Pro right away; PayPal retries automatically, and a successful retry restores it.

## Before you launch
- Add a short **Terms & Refund policy** page (PayPal expects one) and link it from the site footer.
- Ask your accountant about sales tax on digital subscriptions and how the income is booked.
- Reports are built in the visitor's browser from data the map already loads, so a technically skilled person could bypass the paywall from the browser console. The paywall stops ordinary users and records who pays; it doesn't lock the data itself.
