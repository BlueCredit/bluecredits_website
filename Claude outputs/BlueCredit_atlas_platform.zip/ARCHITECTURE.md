# BlueCredit Atlas: architecture

Atlas has three parts: the **front end** (the map), the **Atlas API** and the **Atlas database**. All three run on the Contabo VPS next to bluecredits-core, which still owns accounts, plans and billing.

```
                         Browser (atlas.bluecredits.org)
                                    │
                     ┌──────────────┴───────────────┐
                     │ nginx on the VPS (TLS, gzip) │
                     └──────┬─────────────────┬─────┘
             static files   │                 │  /api/*
          (frontend → dist) │                 ▼
                            │      ┌─────────────────────┐   plan check    ┌──────────────────────┐
                            │      │ Atlas API (FastAPI)  │ ──────────────▶ │ bluecredits-core     │
                            │      │ docker: api :8085    │  /sso/session   │ accounts, plans,     │
                            │      └───┬────────────┬────┘  (cached 5 min) │ PayPal (unchanged)   │
                            │          │            │                       └──────────────────────┘
                            │          ▼            ▼ cache miss
                            │  ┌──────────────┐   USGS Water Data, OpenFEMA
                            │  │ PostGIS 16   │
                            │  │ docker: db   │
                            │  └──────────────┘
                            ▼
      Live map services the browser still calls directly (ArcGIS-style tile and feature services):
      EPA, USGS WBD/NHD, USFWS, NOAA NWM, U.S. Drought Monitor, FEMA NFHL/NRI, USACE NID, Esri, Google tiles
```

## 1. Front end (`frontend/`)

- It's the same map as before: `index.html`, `pages/terms.html`, `404.html`, `js/account.js` and `data/`.
- One new file, **`js/api.js`**, connects the map to the API. It's switched on by one setting at the top of `index.html`: `window.BC_API`.
  - **Empty:** the map works exactly as before, reading the files in `data/`, with no server needed.
  - **Set** (for example `https://atlas.bluecredits.org`):
    - Every `data/<file>` request is answered by the API from the database.
    - USGS and OpenFEMA requests go through the API's shared cache.
    - Report opens and downloads are logged to the visitor's BlueCredit account.
  - No map code changed. If the API is down, free data falls back to the original files and live sources fall back to the original services.
- **`deploy/build_frontend.sh`** builds the public site into `dist/`. It sets the API address and **leaves out Pro-only data files**, so `hospitality.json` (licensed) is never downloadable by the public.

## 2. Atlas API (`api/`, Python FastAPI)

The interactive docs are at `/api/docs`.

| Endpoint | What it does | Access |
|---|---|---|
| `GET /api/v1/health` | Checks the database and shows the last data load | public |
| `GET /api/v1/datasets` | Catalog: title, source, license, version, rows, last loaded, whether you can download it | public |
| `GET /api/v1/datasets/{file}` | The dataset file the map uses (same bytes as the original), with an ETag and caching | free data public; **Pro data needs Pro** |
| `GET /api/v1/features/{name}?bbox=` | GeoJSON for just the visible area, for future "load what's on screen" layers | same as above |
| `POST /api/v1/query/area` | For a drawn shape, basin or utility: counts and totals per dataset, plus USGS county water use weighted by the share of each county inside | Pro datasets only for Pro |
| `GET /api/v1/query/near?lat&lng&radius_mi` | Nearest facilities with distances, plus the county's water use | same |
| `GET /api/v1/proxy/usgs/…`, `/proxy/fema/…` | Cached USGS Water Data and OpenFEMA calls (live readings 5 min, daily 6 h, metadata and claims 7 days); serves the last good copy if USGS is down; adds the USGS API key on the server | public |
| `POST /api/v1/usage/report`, `GET /api/v1/usage/me` | Logs report activity per account; optional monthly limit (`REPORT_MONTHLY_LIMIT`, Enterprise exempt) | signed in |

**Who is Pro.**
- The browser already holds an *entitlement* token from "Sign in with BlueCredit". `js/api.js` sends it as `Authorization: Entitlement <token>`.
- The API asks bluecredits-core (`POST /api/v1/sso/session`) for the plan and remembers the answer for 5 minutes.
- Atlas stores no passwords and no billing. Plans live only in bluecredits-core.

## 3. Atlas database (`db/`, PostgreSQL 16 + PostGIS)

| Table | Holds |
|---|---|
| `atlas.datasets` | One row per dataset: title, file name, format, **access (free/pro)**, source, license, version, refresh schedule, row count, checksum, when loaded |
| `atlas.features` | Every row of every dataset with a PostGIS geometry (points, data center footprints, county polygons) and its attributes; spatially indexed |
| `atlas.documents` | The original file for each dataset, served to the map unchanged |
| `atlas.api_cache` | Cached USGS and OpenFEMA responses with expiry times |
| `atlas.report_log` | Report opens and downloads per BlueCredit user (for usage stats and the optional monthly limit) |
| `atlas.schema_migrations` | Which `db/migrations/*.sql` files have run |

Current contents: 11 datasets, about 95,000 rows, including 3,231 county polygons. A load replaces a dataset in one transaction, so the map never sees half-loaded data.

## 4. Managing data

`api/app/registry.py` is the single list of datasets: file, format, title, source, license, **free or Pro**, and the fields totaled in area queries.

```
docker compose run --rm loader                     # load all datasets from frontend/data
docker compose run --rm loader load industrial_facilities
docker compose run --rm loader status              # what's loaded, row counts, dates
```

**Yearly refresh:**

| Dataset | When to refresh |
|---|---|
| TRI, EIA | every fall |
| IM3 | with each release |
| CWNS | every 4 years |
| USGS county water use | when USGS publishes |
| FOIA and offsets CSVs | whenever new records arrive |

For any of these, replace the file in `frontend/data` and run `loader load <name>`. `api/etl/sources/build_water_demand.py` rebuilds the USGS county file.

**Making a dataset Pro-only:** set `access="pro"` in the registry, reload it, then rebuild the front end. The API refuses it without Pro, and the build leaves its file out of the public site.

## 5. What's protected now that wasn't before

- **Hospitality data:** the licensed Lodging Econometrics file is served only to Pro accounts. Before, it was a public file anyone could download.
- **USGS limits:** USGS rate limits are shared across all visitors through the cache, and the USGS API key never reaches browsers.
- **Report activity:** recorded per account, so a monthly Pro report limit can be switched on without touching the map.

## 6. Next steps (optional, not built yet)

- Switch the biggest layers (industrial facilities, hospitality, wastewater plants) to `/features?bbox=` so the map loads only what's on screen instead of whole files.
- Have the report builder use `/query/area` and `/query/near` instead of counting in the browser. That makes large basins faster.
- Turn on the monthly report limit (`REPORT_MONTHLY_LIMIT=10`) and show "x of 10 reports used" in the account menu.
