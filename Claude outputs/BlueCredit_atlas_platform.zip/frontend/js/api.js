/*
 * BlueCredit Atlas: connect the map to the Atlas API (api/ in this project).
 *
 * Set the API address in index.html before this file loads:
 *     <script>window.BC_API = 'https://atlas.bluecredits.org';</script>
 * Leave it empty ('') to run as a plain static site from the files in data/ (how it worked before).
 *
 * With the API on, without changing any map code:
 *   - data/<file> requests are served from the database (/api/v1/datasets/<file>); Pro-only files
 *     (hospitality) are sent only to signed-in Pro accounts, so they no longer need to be public files;
 *   - USGS Water Data and OpenFEMA requests go through the API's shared cache (/api/v1/proxy/...);
 *   - report opens/downloads are logged to the visitor's BlueCredit account (/api/v1/usage/report).
 * If the API can't be reached, free data and live services fall back to their original addresses.
 */
(function () {
    'use strict';
    const API = (window.BC_API || '').replace(/\/+$/, '');
    if (!API) return;
    const PROXY = window.BC_API_PROXY !== false;
    const UPSTREAM = [
        ['https://api.waterdata.usgs.gov/ogcapi/v0/', '/api/v1/proxy/usgs/'],
        ['https://www.fema.gov/api/open/', '/api/v1/proxy/fema/']
    ];
    const nativeFetch = window.fetch.bind(window);

    function entitlement() {
        try { const s = JSON.parse(localStorage.getItem('bc_atlas_session') || 'null'); return s && s.entitlement; } catch (e) { return null; }
    }
    function withAuth(init) {
        const t = entitlement(); if (!t) return init;
        const h = new Headers((init && init.headers) || {}); h.set('Authorization', 'Entitlement ' + t);
        return Object.assign({}, init || {}, { headers: h });
    }
    // Where should this request go? Returns [apiUrl, fallbackUrl|null, needsAuth] or null to leave it alone.
    function route(url) {
        const m = /^(?:\.\/|\/)?data\/([\w.-]+)$/.exec(url);
        if (m) return [API + '/api/v1/datasets/' + m[1], url, true];
        if (PROXY) for (const [from, to] of UPSTREAM) if (url.startsWith(from)) return [API + to + url.slice(from.length), url, false];
        return null;
    }

    window.fetch = function (input, init) {
        const url = typeof input === 'string' ? input : (input && input.url) || '';
        const r = typeof input === 'string' ? route(url) : null;
        if (!r) return nativeFetch(input, init);
        const [apiUrl, fallback, auth] = r;
        return nativeFetch(apiUrl, auth ? withAuth(init) : init).then(res => {
            if (res.status >= 500 && fallback) return nativeFetch(fallback, init);   // API trouble: use the original source
            return res;                                                             // 401/403 for Pro data are passed on
        }, err => fallback ? nativeFetch(fallback, init) : Promise.reject(err));
    };

    // Report activity → the visitor's BlueCredit account (account.js defines a no-op; replace it once it has loaded)
    function logReport(name, params) {
        if (!entitlement()) return;
        const meta = {};
        Object.entries(params || {}).slice(0, 8).forEach(([k, v]) => { if (v != null) meta[k] = String(v).slice(0, 120); });
        nativeFetch(API + '/api/v1/usage/report', withAuth({ method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ kind: name, meta }) })).catch(() => {});
    }
    window.addEventListener('load', () => { window.dcwlLogReport = logReport; });
    window.BC_API_CLIENT = { base: API, entitlement, fetch: (path, init) => nativeFetch(API + path, withAuth(init)) };
})();
