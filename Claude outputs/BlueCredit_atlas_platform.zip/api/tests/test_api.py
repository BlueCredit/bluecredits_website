"""API tests against a real PostGIS database loaded with the Atlas data (python -m etl load all first).

  DATABASE_URL=postgresql://... pytest -q
"""
import pytest
from fastapi.testclient import TestClient

from app import auth
from app.main import app

PRO = {"Authorization": "Entitlement pro-token"}
FREE = {"Authorization": "Entitlement free-token"}
FAIRFAX = {"type": "Polygon", "coordinates": [[[-77.5, 38.75], [-77.1, 38.75], [-77.1, 39.0], [-77.5, 39.0], [-77.5, 38.75]]]}


@pytest.fixture(scope="module")
def client():
    def fake_core(token):
        if token == "pro-token":
            return auth.Visitor(user_id="u-pro", pro=True, tier="pro")
        if token == "free-token":
            return auth.Visitor(user_id="u-free", pro=False, tier="free")
        return auth.Visitor()
    auth._ask_core = fake_core
    auth._cache.clear()
    with TestClient(app) as c:
        yield c


def test_health(client):
    r = client.get("/api/v1/health").json()
    assert r["status"] == "ok" and r["datasets"] >= 11


def test_catalog_marks_pro(client):
    d = {x["name"]: x for x in client.get("/api/v1/datasets").json()["datasets"]}
    assert d["hospitality"]["access"] == "pro" and d["hospitality"]["available"] is False
    assert d["industrial_facilities"]["available"] is True
    d = {x["name"]: x for x in client.get("/api/v1/datasets", headers=PRO).json()["datasets"]}
    assert d["hospitality"]["available"] is True


def test_dataset_file_is_byte_identical(client):
    import os
    from app.config import settings
    for name, f in [("industrial_facilities", "industrial_facilities.json"), ("datacenters_wateruse", "datacenters_wateruse.csv"), ("water_demand", "water_demand.json")]:
        r = client.get(f"/api/v1/datasets/{f}")
        assert r.status_code == 200
        assert r.content == open(os.path.join(settings.data_dir, f), "rb").read()
        assert client.get(f"/api/v1/datasets/{name}", headers={"If-None-Match": r.headers["etag"]}).status_code == 304


def test_pro_dataset_locked(client):
    assert client.get("/api/v1/datasets/hospitality.json").status_code == 401
    assert client.get("/api/v1/datasets/hospitality.json", headers=FREE).status_code == 403
    r = client.get("/api/v1/datasets/hospitality.json", headers=PRO)
    assert r.status_code == 200 and r.headers["cache-control"].startswith("private")


def test_features_bbox(client):
    r = client.get("/api/v1/features/industrial_facilities", params={"bbox": "-77.6,38.7,-77.0,39.1", "limit": 5}).json()
    assert r["type"] == "FeatureCollection" and 0 < len(r["features"]) <= 5
    lon, lat = r["features"][0]["geometry"]["coordinates"]
    assert -77.6 <= lon <= -77.0 and 38.7 <= lat <= 39.1
    assert client.get("/api/v1/features/hospitality", params={"bbox": "-77.6,38.7,-77.0,39.1"}).status_code == 401
    assert client.get("/api/v1/features/industrial_facilities", params={"bbox": "1,2"}).status_code == 400


def test_area_query(client):
    r = client.post("/api/v1/query/area", json={"geometry": FAIRFAX}).json()
    assert 300 < r["area_sq_mi"] < 700
    assert r["datasets"]["datacenters_estimated"]["count"] > 0
    assert "hospitality" not in r["datasets"]                      # free visitor: Pro data left out
    assert r["water_demand_mgd"]["totals"]["tot"] > 0 and r["water_demand_mgd"]["counties"]
    r = client.post("/api/v1/query/area", json={"geometry": FAIRFAX, "datasets": ["hospitality"]}, headers=PRO).json()
    assert r["datasets"]["hospitality"]["count"] > 0 and r["datasets"]["hospitality"]["totals"]["rooms"] > 0
    assert client.post("/api/v1/query/area", json={"geometry": FAIRFAX, "datasets": ["hospitality"]}).status_code == 401
    huge = {"type": "Polygon", "coordinates": [[[-120, 30], [-80, 30], [-80, 45], [-120, 45], [-120, 30]]]}
    assert client.post("/api/v1/query/area", json={"geometry": huge}).status_code == 400


def test_foia_points_land_in_virginia(client):
    # the FOIA CSVs store latitude in X and longitude in Y
    r = client.post("/api/v1/query/area", json={"geometry": FAIRFAX, "datasets": ["datacenters_wateruse"]}).json()
    assert r["datasets"]["datacenters_wateruse"]["count"] > 0


def test_near(client):
    r = client.get("/api/v1/query/near", params={"lat": 39.0, "lng": -77.45, "radius_mi": 5, "datasets": "datacenters_estimated,wastewater_plants"}).json()
    ds = r["datasets"]["datacenters_estimated"]
    assert ds and ds == sorted(ds, key=lambda x: x["distance_mi"]) and ds[-1]["distance_mi"] <= 5
    assert r["county_water_use_2015"]["st"] == "VA"


def test_usage_and_limit(client, monkeypatch):
    from app.config import settings
    from app.db import pool
    with pool().connection() as c:
        c.execute("DELETE FROM atlas.report_log WHERE user_id IN ('u-pro','u-free')")
    assert client.post("/api/v1/usage/report", json={"kind": "site_report_open"}).status_code == 401
    monkeypatch.setattr(settings, "report_monthly_limit", 2)
    for _ in range(2):
        assert client.post("/api/v1/usage/report", json={"kind": "site_report_open"}, headers=PRO).status_code == 200
    assert client.post("/api/v1/usage/report", json={"kind": "site_report_download", "meta": {"format": "pdf"}}, headers=PRO).status_code == 200
    assert client.post("/api/v1/usage/report", json={"kind": "basin_report_open"}, headers=PRO).status_code == 429
    me = client.get("/api/v1/usage/me", headers=PRO).json()
    assert me["reports_this_month"] == 2 and me["remaining"] == 0


def test_proxy_rejects_unknown_hosts(client):
    assert client.get("/api/v1/proxy/evil/x").status_code == 404
    assert client.get("/api/v1/proxy/usgs/../../etc").status_code in (404, 400)


def test_proxy_caches(client, monkeypatch):
    from app.routers import proxy
    calls = []

    class R:
        status_code = 200; content = b'{"ok":1}'; headers = {"content-type": "application/json"}
    monkeypatch.setattr(proxy._client, "get", lambda url, headers=None: calls.append(url) or R())
    q = "collections/monitoring-locations/items?id=USGS-TEST-" + str(id(calls))
    a = client.get("/api/v1/proxy/usgs/" + q); b = client.get("/api/v1/proxy/usgs/" + q)
    assert a.content == b'{"ok":1}' and a.headers["x-cache"] == "MISS" and b.headers["x-cache"] == "HIT" and len(calls) == 1
