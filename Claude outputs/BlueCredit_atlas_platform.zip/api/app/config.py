"""Settings from environment variables (see .env.example)."""
import os


def _list(name, default=""):
    return [x.strip().rstrip("/") for x in os.getenv(name, default).split(",") if x.strip()]


class Settings:
    database_url = os.getenv("DATABASE_URL", "postgresql://atlas:atlas@localhost:5432/atlas")
    # BlueCredit account backend (bluecredits-core). Atlas asks it for the visitor's plan.
    core_api_url = os.getenv("CORE_API_URL", "https://marketplace.bluecredits.org").rstrip("/")
    # Sites allowed to call this API from the browser
    cors_origins = _list("CORS_ORIGINS", "https://atlas.bluecredits.org,http://localhost:8792")
    # Folder with the original data files (used by the loader)
    data_dir = os.getenv("DATA_DIR", os.path.join(os.path.dirname(__file__), "..", "..", "frontend", "data"))
    # Optional USGS Water Data API key (raises USGS rate limits; stays on the server)
    usgs_api_key = os.getenv("USGS_API_KEY", "")
    # Pro report limit per calendar month (0 = unlimited). Enterprise is always unlimited.
    report_monthly_limit = int(os.getenv("REPORT_MONTHLY_LIMIT", "0"))
    # Seconds to remember a visitor's plan before asking bluecredits-core again
    plan_cache_seconds = int(os.getenv("PLAN_CACHE_SECONDS", "300"))
    # Development only: treat every visitor as Pro (never set in production)
    dev_all_pro = os.getenv("DEV_ALL_PRO", "") == "1"


settings = Settings()
