"""BlueCredit Atlas API.

Serves the map's datasets from Postgres/PostGIS (with Pro-only datasets locked behind the BlueCredit plan),
answers area / nearby / bounding-box questions, caches slow outside APIs (USGS, FEMA) and logs report use.
Interactive docs: /api/docs
"""
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware

from . import db
from .config import settings
from .routers import datasets, features, health, proxy, query, usage

VERSION = "1.0.0"


@asynccontextmanager
async def lifespan(app):
    db.migrate()
    yield
    db.close()


app = FastAPI(title="BlueCredit Atlas API", version=VERSION, lifespan=lifespan,
              docs_url="/api/docs", openapi_url="/api/openapi.json", redoc_url=None)
app.add_middleware(GZipMiddleware, minimum_size=1024)
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins, allow_methods=["GET", "POST", "OPTIONS"],
                   allow_headers=["Authorization", "Content-Type", "If-None-Match"], expose_headers=["ETag"], max_age=3600)

for r in (health.router, datasets.router, features.router, query.router, proxy.router, usage.router):
    app.include_router(r, prefix="/api/v1")
