"""Every dataset Atlas serves: where it comes from, who may see it, and how it's queried.

To add a dataset: put the file in frontend/data, add an entry here, run `python -m etl load <name>`.
To make a dataset Pro-only: set access='pro' and reload (the API then refuses it without a Pro plan,
and deploy/build_frontend.sh leaves the file out of the public site).
"""

DATASETS = {
    # ── Data centers ──
    "datacenters_wateruse": dict(
        file="datacenters_wateruse.csv", format="csv", title="Data center water use (FOIA records)",
        access="free",   # the map layer is Pro, but basin popups and search use these totals; set 'pro' to lock all of it
        lat="X", lon="Y", label="Location", sums=["Gallons"],   # in these CSVs X holds latitude and Y longitude
        source="Public-records (FOIA) responses and utility data compiled by BlueCredit", license="BlueCredit", refresh="as received"),
    "datacenters_wateroffsets": dict(
        file="datacenters_wateroffsets.csv", format="csv", title="Data center water replenishment and recycled water projects",
        access="free", lat="X", lon="Y", label="Project", sums=["Gallons"],
        source="Company disclosures and utility data compiled by BlueCredit", license="BlueCredit", refresh="as received"),
    "datacenters_waterreclaimed": dict(
        file="datacenters_waterreclaimed.csv", format="csv", title="Reclaimed water delivered to data centers (Loudoun Water)",
        access="free", source="Loudoun Water billing data (utility-reported aggregate)", license="BlueCredit", refresh="as received"),
    "datacenters_estimated": dict(
        file="datacenters_estimated.geojson", format="geojson", title="Data centers (IM3 Open Source Data Center Atlas)",
        access="free", label="nm", sums=["sqft"],
        source="Mongird et al. (2026), PNNL IM3, doi:10.57931/3017294", license="ODbL (OpenStreetMap-derived)", version="2026.02.09", refresh="yearly"),
    "datacenters_projected": dict(
        file="datacenters_projected.json", format="scenarios", title="Projected data center sites, 2035 (IM3)",
        access="free", lat="lat", lon="lng", sums=["data_center_it_power_mw", "cooling_water_demand_mgy", "cooling_water_consumption_mgy"],
        source="Mongird et al. (2026), PNNL IM3, doi:10.57931/3020186", license="CC BY 4.0", version="1.1", refresh="yearly"),
    # ── Water demand and facilities ──
    "water_demand": dict(
        file="water_demand.json", format="topojson", title="Water use by sector and county, 2015 (USGS)",
        access="free", label="cn", sums=["d", "ps", "i", "m", "ir", "li", "aq", "t", "tot"],
        source="USGS, Estimated Use of Water in the United States, County-Level Data for 2015 (doi:10.5066/F7TB15V5)", license="Public domain", version="2015", refresh="when USGS publishes"),
    "industrial_facilities": dict(
        file="industrial_facilities.json", format="rows", title="Industrial facilities by sector (EPA TRI)",
        access="free", label="name", sums=["water_lb", "potw_lb", "total_lb"],
        source="U.S. EPA Toxics Release Inventory", license="Public domain", version="2024", refresh="yearly (fall)"),
    "plant_cooling": dict(
        file="plant_cooling.json", format="rows", title="Power plant cooling water (EIA)",
        access="free", label="name", sums=["withdrawal_mgal", "consumption_mgal", "mw"],
        source="U.S. EIA thermoelectric cooling water data", license="Public domain", version="2024", refresh="yearly (fall)"),
    "wastewater_plants": dict(
        file="wastewater_plants.json", format="rows", title="Wastewater treatment plants (EPA CWNS)",
        access="free", label="name", sums=["design_flow_mgd", "pop_served_2022"],
        source="U.S. EPA 2022 Clean Watersheds Needs Survey", license="Public domain", version="2022", refresh="every 4 years"),
    "higher_education": dict(
        file="higher_education.json", format="rows", title="Higher education (HIFLD / NCES)",
        access="free", label="name", sums=["enroll", "dorm_cap", "employees"],
        source="DHS HIFLD Colleges and Universities (NCES IPEDS)", license="Public domain", refresh="yearly"),
    "hospitality": dict(
        file="hospitality.json", format="rows", title="Hospitality (Lodging Econometrics)",
        access="pro",    # licensed data: served only to Pro accounts and never published as a public file
        label="name", sums=["rooms"],
        source="Lodging Econometrics hotel census and pipeline", license="Licensed; no redistribution", refresh="quarterly"),
}

# Datasets whose rows are tied to an area query with /query/area (points only; county polygons handled separately)
POINT_DATASETS = [k for k, v in DATASETS.items() if v["format"] in ("rows", "geojson", "scenarios") or v.get("lat")]

FILE_TO_NAME = {v["file"]: k for k, v in DATASETS.items()}
