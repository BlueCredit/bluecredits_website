"""Who is calling, and do they have Atlas Pro?

The browser sends the entitlement token it got from "Sign in with BlueCredit" (js/account.js):
    Authorization: Entitlement <token>
We ask bluecredits-core (POST /api/v1/sso/session) for the plan and remember the answer for a few minutes.
Atlas never sees passwords and never stores plans itself, so billing stays in one place.
"""
import hashlib
import time
from dataclasses import dataclass, field

import httpx
from fastapi import Header, HTTPException

from .config import settings


@dataclass
class Visitor:
    user_id: str | None = None
    pro: bool = False
    tier: str = "free"
    plan: dict = field(default_factory=dict)

    @property
    def signed_in(self):
        return self.user_id is not None


_cache: dict[str, tuple[float, Visitor]] = {}


def _ask_core(token: str) -> Visitor:
    try:
        r = httpx.post(f"{settings.core_api_url}/api/v1/sso/session", json={"entitlement": token}, timeout=8)
    except httpx.HTTPError:
        raise HTTPException(503, "The BlueCredit account service is unavailable. Please try again.")
    if r.status_code == 401:
        return Visitor()
    if r.status_code != 200:
        raise HTTPException(503, "Could not check your plan right now.")
    p = (r.json() or {}).get("payload") or {}
    plan = p.get("plan") or {}
    return Visitor(user_id=(p.get("user") or {}).get("id"), pro=bool(plan.get("app_pro")), tier=plan.get("tier") or "free", plan=plan)


def visitor(authorization: str | None = Header(default=None)) -> Visitor:
    """FastAPI dependency: the current visitor (anonymous if no or bad token)."""
    if settings.dev_all_pro:
        return Visitor(user_id="dev", pro=True, tier="pro")
    if not authorization or not authorization.lower().startswith("entitlement "):
        return Visitor()
    token = authorization.split(" ", 1)[1].strip()
    key = hashlib.sha256(token.encode()).hexdigest()
    hit = _cache.get(key)
    if hit and hit[0] > time.time():
        return hit[1]
    v = _ask_core(token)
    _cache[key] = (time.time() + settings.plan_cache_seconds, v)
    if len(_cache) > 5000:                       # keep memory bounded
        for k in sorted(_cache, key=lambda k: _cache[k][0])[:1000]:
            _cache.pop(k, None)
    return v


def require_pro(v: Visitor):
    if not v.signed_in:
        raise HTTPException(401, "Sign in with BlueCredit to use this data.")
    if not v.pro:
        raise HTTPException(403, "This data is part of Atlas Pro.")
