"""Postgres connection pool and migrations."""
import glob
import os

from psycopg.rows import dict_row
from psycopg_pool import ConnectionPool

from .config import settings

_pool = None
MIGRATIONS = os.getenv("MIGRATIONS_DIR", os.path.join(os.path.dirname(__file__), "..", "..", "db", "migrations"))


def pool():
    global _pool
    if _pool is None:
        _pool = ConnectionPool(settings.database_url, min_size=1, max_size=int(os.getenv("DB_POOL_MAX", "10")),
                               kwargs={"row_factory": dict_row, "autocommit": True}, open=True)
    return _pool


def close():
    global _pool
    if _pool is not None:
        _pool.close()
        _pool = None


def migrate():
    """Apply db/migrations/*.sql in order, once each."""
    with pool().connection() as c:
        c.execute("CREATE SCHEMA IF NOT EXISTS atlas")
        c.execute("CREATE TABLE IF NOT EXISTS atlas.schema_migrations (version text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())")
        done = {r["version"] for r in c.execute("SELECT version FROM atlas.schema_migrations").fetchall()}
        applied = []
        for path in sorted(glob.glob(os.path.join(MIGRATIONS, "*.sql"))):
            v = os.path.basename(path)
            if v in done:
                continue
            with c.transaction():
                c.execute(open(path, encoding="utf-8").read())
                c.execute("INSERT INTO atlas.schema_migrations (version) VALUES (%s)", (v,))
            applied.append(v)
        return applied
