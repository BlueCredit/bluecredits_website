from fastapi import APIRouter

from ..db import pool

router = APIRouter(tags=["health"])


@router.get("/health")
def health():
    with pool().connection() as c:
        r = c.execute("SELECT count(*) AS n, max(loaded_at) AS last FROM atlas.datasets").fetchone()
    return {"status": "ok", "datasets": r["n"], "last_load": r["last"]}
