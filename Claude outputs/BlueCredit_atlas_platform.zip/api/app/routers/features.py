"""GeoJSON features inside a bounding box, for map layers that load only what's on screen."""
import json

from fastapi import APIRouter, Depends, HTTPException, Query

from ..auth import Visitor, require_pro, visitor
from ..db import pool
from .datasets import find

router = APIRouter(tags=["features"])


def parse_bbox(bbox):
    try:
        w, s, e, n = [float(x) for x in bbox.split(",")]
    except (ValueError, AttributeError):
        raise HTTPException(400, "bbox must be west,south,east,north in degrees.")
    if not (-180 <= w < e <= 180 and -90 <= s < n <= 90):
        raise HTTPException(400, "bbox is out of range.")
    return w, s, e, n


@router.get("/features/{name}")
def features(name: str, bbox: str = Query(..., description="west,south,east,north"),
             limit: int = Query(2000, ge=1, le=10000), scenario: str | None = None, v: Visitor = Depends(visitor)):
    """Features of one dataset inside the box, in the file's original order (largest first where the file is sorted)."""
    w, s, e, n = parse_bbox(bbox)
    with pool().connection() as c:
        d = find(c, name)
        if d["access"] == "pro":
            require_pro(v)
        sql = """SELECT fid, props, ST_AsGeoJSON(geom, 6) AS g FROM atlas.features
                 WHERE dataset=%s AND geom && ST_MakeEnvelope(%s,%s,%s,%s,4326)"""
        args = [d["name"], w, s, e, n]
        if scenario:
            sql += " AND props->>'scenario' = %s"; args.append(scenario)
        sql += " ORDER BY fid LIMIT %s"; args.append(limit + 1)
        rows = c.execute(sql, args).fetchall()
    more = len(rows) > limit
    feats = [{"type": "Feature", "id": r["fid"], "geometry": json.loads(r["g"]) if r["g"] else None, "properties": r["props"]} for r in rows[:limit]]
    return {"type": "FeatureCollection", "dataset": d["name"], "truncated": more, "features": feats}
