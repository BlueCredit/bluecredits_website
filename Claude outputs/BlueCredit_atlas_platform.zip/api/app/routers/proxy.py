"""Cached pass-through to slow or rate-limited public APIs.

  /api/v1/proxy/usgs/<path>?<query>  ->  https://api.waterdata.usgs.gov/ogcapi/v0/<path>
  /api/v1/proxy/fema/<path>?<query>  ->  https://www.fema.gov/api/open/<path>

Responses are stored in atlas.api_cache for a time that depends on how often the data changes, so many
visitors looking at the same gage or county cost one upstream call. A USGS API key (USGS_API_KEY) is added
on the server and never reaches the browser. Only these two upstreams are allowed (no open proxy).
"""
import hashlib
from datetime import datetime, timedelta, timezone

import httpx
from fastapi import APIRouter, HTTPException, Request, Response

from ..config import settings
from ..db import pool

router = APIRouter(tags=["proxy"])

UPSTREAMS = {
    "usgs": "https://api.waterdata.usgs.gov/ogcapi/v0/",
    "fema": "https://www.fema.gov/api/open/",
}
MAX_BYTES = 25 * 1024 * 1024


def ttl(source, path):
    """Seconds to keep a response."""
    if source == "usgs":
        if "latest-continuous" in path or "continuous" in path:
            return 5 * 60                     # live readings
        if "daily" in path:
            return 6 * 3600
        return 7 * 24 * 3600                  # monitoring-locations and other metadata
    return 7 * 24 * 3600                      # FEMA claims (updated monthly at most)


_client = httpx.Client(timeout=30, follow_redirects=True, headers={"User-Agent": "BlueCreditAtlas/1.0 (+https://atlas.bluecredits.org)"})


@router.get("/proxy/{source}/{path:path}")
def proxy(source: str, path: str, request: Request):
    base = UPSTREAMS.get(source)
    if not base or ".." in path or path.startswith("/"):
        raise HTTPException(404, "Unknown source.")
    qs = request.url.query
    url = base + path + ("?" + qs if qs else "")
    key = hashlib.sha256(f"{source}|{path}|{qs}".encode()).hexdigest()
    now = datetime.now(timezone.utc)
    with pool().connection() as c:
        hit = c.execute("SELECT status, content_type, body, expires_at FROM atlas.api_cache WHERE key=%s", (key,)).fetchone()
        if hit and hit["expires_at"] > now:
            age = int((hit["expires_at"] - now).total_seconds())
            return Response(bytes(hit["body"]), status_code=hit["status"], media_type=hit["content_type"],
                            headers={"X-Cache": "HIT", "Cache-Control": f"public, max-age={max(0, age)}"})
    headers = {"Accept": request.headers.get("accept", "application/json")}
    if source == "usgs" and settings.usgs_api_key:
        headers["X-Api-Key"] = settings.usgs_api_key
    try:
        r = _client.get(url, headers=headers)
    except httpx.HTTPError:
        if hit:                                   # upstream down: serve the stale copy rather than nothing
            return Response(bytes(hit["body"]), status_code=hit["status"], media_type=hit["content_type"], headers={"X-Cache": "STALE"})
        raise HTTPException(502, f"{source.upper()} did not respond.")
    body = r.content[:MAX_BYTES]
    ctype = r.headers.get("content-type", "application/json")
    if r.status_code == 200 and len(r.content) <= MAX_BYTES:
        t = ttl(source, path)
        with pool().connection() as c:
            c.execute("""INSERT INTO atlas.api_cache (key, status, content_type, body, fetched_at, expires_at) VALUES (%s,%s,%s,%s,%s,%s)
                         ON CONFLICT (key) DO UPDATE SET status=EXCLUDED.status, content_type=EXCLUDED.content_type, body=EXCLUDED.body,
                         fetched_at=EXCLUDED.fetched_at, expires_at=EXCLUDED.expires_at""",
                      (key, r.status_code, ctype, body, now, now + timedelta(seconds=t)))
        return Response(body, status_code=200, media_type=ctype, headers={"X-Cache": "MISS", "Cache-Control": f"public, max-age={t}"})
    if hit:
        return Response(bytes(hit["body"]), status_code=hit["status"], media_type=hit["content_type"], headers={"X-Cache": "STALE"})
    return Response(body, status_code=r.status_code, media_type=ctype, headers={"X-Cache": "BYPASS"})
