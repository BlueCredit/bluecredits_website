"""Report activity per BlueCredit account, and the optional monthly report limit for Pro.

REPORT_MONTHLY_LIMIT=10 turns on a 10-reports-a-month cap for Pro (Enterprise is never capped); 0 = off.
"""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from psycopg.types.json import Jsonb
from pydantic import BaseModel, Field

from ..auth import Visitor, visitor
from ..config import settings
from ..db import pool

router = APIRouter(tags=["usage"])
COUNTED = ("_report_open",)          # opening a report counts once; downloads of the same report are logged but not counted


class ReportEvent(BaseModel):
    kind: str = Field(..., max_length=60, pattern=r"^[a-z_]+$")
    meta: dict = Field(default_factory=dict)


def _month_count(c, user_id):
    start = datetime.now(timezone.utc).replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    return c.execute("SELECT count(*) AS n FROM atlas.report_log WHERE user_id=%s AND created_at >= %s AND kind LIKE '%%_report_open'",
                     (user_id, start)).fetchone()["n"]


def _limit(v):
    if not settings.report_monthly_limit or v.tier == "enterprise":
        return None
    return settings.report_monthly_limit


@router.get("/usage/me")
def me(v: Visitor = Depends(visitor)):
    if not v.signed_in:
        raise HTTPException(401, "Sign in with BlueCredit.")
    with pool().connection() as c:
        n = _month_count(c, v.user_id)
    lim = _limit(v)
    return {"reports_this_month": n, "monthly_limit": lim, "remaining": None if lim is None else max(0, lim - n), "pro": v.pro, "tier": v.tier}


@router.post("/usage/report")
def log_report(e: ReportEvent, v: Visitor = Depends(visitor)):
    if not v.signed_in:
        raise HTTPException(401, "Sign in with BlueCredit.")
    meta = {k: (str(val)[:200]) for k, val in list(e.meta.items())[:12]}     # small, no free text blobs
    with pool().connection() as c:
        n = _month_count(c, v.user_id)
        lim = _limit(v)
        if lim is not None and e.kind.endswith(COUNTED) and n >= lim:
            raise HTTPException(429, f"You've used your {lim} reports for this month.")
        c.execute("INSERT INTO atlas.report_log (user_id, kind, meta) VALUES (%s,%s,%s)", (v.user_id, e.kind, Jsonb(meta)))
    n += 1 if e.kind.endswith(COUNTED) else 0
    return {"ok": True, "reports_this_month": n, "monthly_limit": lim}
