"""Questions about a place: what's inside an area (drawn shape, basin, utility), and what's near a point.

These run in PostGIS, so reports no longer need to download whole datasets to the browser to count them.
"""
import json

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from ..auth import Visitor, require_pro, visitor
from ..db import pool
from ..registry import DATASETS

router = APIRouter(tags=["query"])
MAX_AREA_SQ_MI = 60000
SQM_PER_SQMI = 2589988.11
POINTS = [k for k, v in DATASETS.items() if k != "water_demand" and (v["format"] in ("rows", "geojson", "scenarios") or v.get("lat"))]


class AreaQuery(BaseModel):
    geometry: dict = Field(..., description="GeoJSON Polygon/MultiPolygon, or a Feature containing one")
    datasets: list[str] | None = Field(None, description="Defaults to every point dataset you can access")
    rows: int = Field(0, ge=0, le=2000, description="Also return up to this many rows per dataset")
    scenario: str | None = Field("moderate_50", description="Scenario for projected data centers")


def _geom(g):
    if g.get("type") == "Feature":
        g = g.get("geometry") or {}
    if g.get("type") not in ("Polygon", "MultiPolygon"):
        raise HTTPException(400, "geometry must be a GeoJSON Polygon or MultiPolygon.")
    return json.dumps(g)


def _allowed(names, v):
    names = names or POINTS
    bad = [n for n in names if n not in DATASETS]
    if bad:
        raise HTTPException(400, f"Unknown dataset(s): {', '.join(bad)}")
    if any(DATASETS[n]["access"] == "pro" for n in names):
        if not v.pro:
            # quietly drop Pro datasets for free visitors when they didn't ask for them explicitly
            names = [n for n in names if DATASETS[n]["access"] == "free"] if names is POINTS else names
            if any(DATASETS[n]["access"] == "pro" for n in names):
                require_pro(v)
    return names


def _sums(name):
    return [f for f in DATASETS[name].get("sums", [])]


@router.post("/query/area")
def area(q: AreaQuery, v: Visitor = Depends(visitor)):
    """Counts and totals for each dataset inside the area, plus USGS county water use weighted by the share of
    each county inside the area."""
    gj = _geom(q.geometry)
    names = _allowed(q.datasets, v)
    out = {}
    with pool().connection() as c:
        a = c.execute("SELECT ST_Area(g::geography) AS m2, ST_IsValid(g) AS ok FROM (SELECT ST_SetSRID(ST_GeomFromGeoJSON(%s),4326) g) s", (gj,)).fetchone()
        sqmi = a["m2"] / SQM_PER_SQMI
        if sqmi > MAX_AREA_SQ_MI:
            raise HTTPException(400, f"Area is {sqmi:,.0f} sq mi; the limit is {MAX_AREA_SQ_MI:,} sq mi.")
        with c.transaction():
            c.execute("CREATE TEMP TABLE IF NOT EXISTS _area (g geometry) ON COMMIT DROP")
            c.execute("INSERT INTO _area SELECT ST_MakeValid(ST_SetSRID(ST_GeomFromGeoJSON(%s),4326))", (gj,))
            for n in names:
                sums = _sums(n)
                sel = ", ".join(f"sum(NULLIF(props->>'{f}','')::float) AS \"{f}\"" for f in sums)
                where = "f.dataset=%s AND ST_Intersects(f.geom, a.g)"
                args = [n]
                if DATASETS[n]["format"] == "scenarios" and q.scenario:
                    where += " AND f.props->>'scenario'=%s"; args.append(q.scenario)
                r = c.execute(f"SELECT count(*) AS count{', ' + sel if sel else ''} FROM atlas.features f, _area a WHERE {where}", args).fetchone()
                res = {"count": r["count"], "totals": {f: r[f] for f in sums}}
                if q.rows:
                    res["rows"] = [x["props"] for x in c.execute(f"SELECT f.props FROM atlas.features f, _area a WHERE {where} ORDER BY f.fid LIMIT %s", args + [q.rows])]
                out[n] = res
            # County water use (USGS 2015), split by the share of each county's area inside the shape
            wd = c.execute("""SELECT f.props, ST_Area(ST_Intersection(f.geom, a.g)::geography) / NULLIF(ST_Area(f.geom::geography),0) AS share
                              FROM atlas.features f, _area a WHERE f.dataset='water_demand' AND ST_Intersects(f.geom, a.g)""").fetchall()
    counties, tot = [], {k: 0.0 for k in DATASETS["water_demand"]["sums"]}
    for r in wd:
        share = min(1.0, r["share"] or 0)
        if share < 0.005:
            continue
        p = r["props"]
        counties.append({"fips": p.get("fips"), "county": p.get("cn"), "state": p.get("st"), "share": round(share, 4)})
        for k in tot:
            tot[k] += (p.get(k) or 0) * share
    return {"area_sq_mi": round(sqmi, 3), "datasets": out,
            "water_demand_mgd": {"counties": sorted(counties, key=lambda x: -x["share"]), "totals": {k: round(v, 3) for k, v in tot.items()},
                                 "note": "USGS 2015 county withdrawals (Mgal/d) multiplied by the share of each county's land inside the area."}}


@router.get("/query/near")
def near(lat: float = Query(..., ge=-90, le=90), lng: float = Query(..., ge=-180, le=180),
         radius_mi: float = Query(10, gt=0, le=100), datasets: str | None = Query(None, description="comma-separated; default all you can access"),
         limit: int = Query(25, ge=1, le=500), v: Visitor = Depends(visitor)):
    """Nearest features to a point within a radius, with distance in miles."""
    names = _allowed([x.strip() for x in datasets.split(",")] if datasets else None, v)
    out = {}
    with pool().connection() as c:
        county = c.execute("""SELECT props FROM atlas.features WHERE dataset='water_demand'
                              AND ST_Intersects(geom, ST_SetSRID(ST_Point(%s,%s),4326)) LIMIT 1""", (lng, lat)).fetchone()
        for n in names:
            rows = c.execute("""SELECT props, ST_Distance(geom::geography, ST_SetSRID(ST_Point(%s,%s),4326)::geography) / 1609.344 AS mi
                                FROM atlas.features WHERE dataset=%s
                                  AND ST_DWithin(geom::geography, ST_SetSRID(ST_Point(%s,%s),4326)::geography, %s)
                                ORDER BY mi LIMIT %s""",
                             (lng, lat, n, lng, lat, radius_mi * 1609.344, limit)).fetchall()
            out[n] = [{**r["props"], "distance_mi": round(r["mi"], 3)} for r in rows]
    return {"lat": lat, "lng": lng, "radius_mi": radius_mi, "county_water_use_2015": county["props"] if county else None, "datasets": out}
