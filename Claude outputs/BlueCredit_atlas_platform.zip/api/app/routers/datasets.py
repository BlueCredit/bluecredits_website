"""The map's data files, served from the database (same bytes as the original files)."""
from fastapi import APIRouter, Depends, HTTPException, Request, Response

from ..auth import Visitor, require_pro, visitor
from ..db import pool

router = APIRouter(tags=["datasets"])


def find(c, name):
    """Look a dataset up by name ('hospitality') or file name ('hospitality.json')."""
    r = c.execute("SELECT * FROM atlas.datasets WHERE name=%s OR file_name=%s", (name, name)).fetchone()
    if not r:
        raise HTTPException(404, "No such dataset.")
    return r


@router.get("/datasets")
def catalog(v: Visitor = Depends(visitor)):
    """Every dataset with its source, license, vintage, size and whether you can download it."""
    with pool().connection() as c:
        rows = c.execute("SELECT name, title, file_name, format, access, source, license, version, refresh, row_count, loaded_at FROM atlas.datasets ORDER BY name").fetchall()
    for r in rows:
        r["available"] = r["access"] == "free" or v.pro
    return {"datasets": rows}


@router.get("/datasets/{name}")
def dataset_file(name: str, request: Request, v: Visitor = Depends(visitor)):
    with pool().connection() as c:
        d = find(c, name)
        if d["access"] == "pro":
            require_pro(v)
        etag = f'"{d["checksum"]}"'
        cache = "private, max-age=600" if d["access"] == "pro" else "public, max-age=3600"
        if request.headers.get("if-none-match") == etag:
            return Response(status_code=304, headers={"ETag": etag, "Cache-Control": cache})
        doc = c.execute("SELECT content_type, body FROM atlas.documents WHERE dataset=%s", (d["name"],)).fetchone()
    return Response(content=bytes(doc["body"]), media_type=doc["content_type"],
                    headers={"ETag": etag, "Cache-Control": cache, "Vary": "Authorization"})
