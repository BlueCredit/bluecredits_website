"""Load the Atlas data files into Postgres/PostGIS.

For each dataset in app/registry.py:
  * the original file is stored in atlas.documents (served unchanged to the map),
  * every row/feature is stored in atlas.features with a PostGIS geometry (for area, nearby and bbox queries),
  * atlas.datasets gets the title, access level, source, row count and a checksum (used as the HTTP ETag).
A load replaces the dataset in one transaction, so the map never sees a half-loaded dataset.
"""
import csv
import hashlib
import io
import json
import os
from datetime import datetime, timezone

from psycopg.types.json import Jsonb

from app.config import settings
from app.db import pool
from app.registry import DATASETS

CONTENT_TYPES = {"csv": "text/csv; charset=utf-8", "geojson": "application/geo+json", "rows": "application/json",
                 "topojson": "application/json", "scenarios": "application/json"}


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _point(lat, lon):
    lat, lon = _num(lat), _num(lon)
    if lat is None or lon is None or not (-90 <= lat <= 90 and -180 <= lon <= 180) or (lat == 0 and lon == 0):
        return None
    return json.dumps({"type": "Point", "coordinates": [lon, lat]})


# ── readers: each yields (props, geojson_geometry_or_None) and returns meta ──

def read_rows(d, cfg):
    fields = d["fields"]
    ilat, ilon = fields.index("lat"), fields.index("lon")
    meta = {k: v for k, v in d.items() if k != "rows"}
    out = [(dict(zip(fields, r)), _point(r[ilat], r[ilon])) for r in d["rows"]]
    return out, meta


def read_geojson(d, cfg):
    meta = {k: v for k, v in d.items() if k != "features"}
    return [(f.get("properties") or {}, json.dumps(f["geometry"]) if f.get("geometry") else None) for f in d["features"]], meta


def read_scenarios(d, cfg):
    fields = d["fields"]
    meta = {k: v for k, v in d.items() if k != "scenarios"}
    meta["scenario_names"] = list(d["scenarios"])
    out = []
    for scen, rows in d["scenarios"].items():
        for r in rows:
            p = dict(zip(fields, r)); p["scenario"] = scen
            out.append((p, _point(p.get(cfg.get("lat", "lat")), p.get(cfg.get("lon", "lon")))))
    return out, meta


def read_csv(text, cfg):
    rows = list(csv.reader(io.StringIO(text)))
    head = [h.strip() for h in rows[0]]
    out = []
    for r in rows[1:]:
        if not any(c.strip() for c in r):
            continue
        p = {head[i]: (r[i] if i < len(r) else "") for i in range(len(head))}
        g = _point(p.get(cfg["lat"]), p.get(cfg["lon"])) if cfg.get("lat") else None
        out.append((p, g))
    return out, {"columns": head}


def _topo_arcs(topo):
    """Decode quantized, delta-encoded TopoJSON arcs to lon/lat."""
    sx, sy = topo["transform"]["scale"]; tx, ty = topo["transform"]["translate"]
    arcs = []
    for arc in topo["arcs"]:
        x = y = 0; pts = []
        for dx, dy in arc:
            x += dx; y += dy
            pts.append([round(x * sx + tx, 6), round(y * sy + ty, 6)])
        arcs.append(pts)
    return arcs


def _ring(arcs, idx):
    pts = []
    for i in idx:
        a = arcs[i] if i >= 0 else arcs[~i][::-1]
        pts.extend(a if not pts else a[1:])
    if pts and pts[0] != pts[-1]:
        pts.append(pts[0])
    return pts


def read_topojson(d, cfg):
    arcs = _topo_arcs(d)
    out = []
    for g in d["objects"]["counties"]["geometries"]:
        if g["type"] == "Polygon":
            geom = {"type": "Polygon", "coordinates": [_ring(arcs, r) for r in g["arcs"]]}
        elif g["type"] == "MultiPolygon":
            geom = {"type": "MultiPolygon", "coordinates": [[_ring(arcs, r) for r in poly] for poly in g["arcs"]]}
        else:
            continue
        p = dict(g.get("properties") or {}); p["fips"] = g.get("id")
        out.append((p, json.dumps(geom)))
    return out, {"objects": list(d["objects"]), "note": "county polygons decoded from TopoJSON"}


def read(name):
    cfg = DATASETS[name]
    path = os.path.join(settings.data_dir, cfg["file"])
    raw = open(path, "rb").read()
    if cfg["format"] == "csv":
        items, meta = read_csv(raw.decode("utf-8-sig"), cfg)
    else:
        d = json.loads(raw)
        items, meta = {"rows": read_rows, "geojson": read_geojson, "scenarios": read_scenarios, "topojson": read_topojson}[cfg["format"]](d, cfg)
    return raw, items, meta


def load(name):
    cfg = DATASETS[name]
    raw, items, meta = read(name)
    checksum = hashlib.sha256(raw).hexdigest()
    with pool().connection() as c, c.transaction():
        c.execute("""INSERT INTO atlas.datasets (name, title, format, file_name, access, source, license, version, refresh, meta, row_count, checksum, loaded_at)
                     VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                     ON CONFLICT (name) DO UPDATE SET title=EXCLUDED.title, format=EXCLUDED.format, file_name=EXCLUDED.file_name,
                       access=EXCLUDED.access, source=EXCLUDED.source, license=EXCLUDED.license, version=EXCLUDED.version,
                       refresh=EXCLUDED.refresh, meta=EXCLUDED.meta, row_count=EXCLUDED.row_count, checksum=EXCLUDED.checksum, loaded_at=EXCLUDED.loaded_at""",
                  (name, cfg["title"], cfg["format"], cfg["file"], cfg["access"], cfg.get("source"), cfg.get("license"), cfg.get("version"),
                   cfg.get("refresh"), Jsonb(meta), len(items), checksum, datetime.now(timezone.utc)))
        c.execute("DELETE FROM atlas.features WHERE dataset=%s", (name,))
        c.execute("CREATE TEMP TABLE IF NOT EXISTS _load (fid integer, gj text, props jsonb) ON COMMIT DROP")
        c.execute("TRUNCATE _load")
        with c.cursor() as cur:
            with cur.copy("COPY _load (fid, gj, props) FROM STDIN") as cp:
                for i, (p, g) in enumerate(items):
                    cp.write_row((i, g, json.dumps(p)))
        # GeoJSON -> PostGIS geometry (polygons are repaired if needed)
        c.execute("""INSERT INTO atlas.features (dataset, fid, geom, props)
                     SELECT %s, fid,
                            CASE WHEN g IS NULL THEN NULL
                                 WHEN GeometryType(g) IN ('POLYGON', 'MULTIPOLYGON') AND NOT ST_IsValid(g) THEN ST_Multi(ST_CollectionExtract(ST_MakeValid(g), 3))
                                 ELSE g END,
                            props
                     FROM (SELECT fid, props, ST_SetSRID(ST_GeomFromGeoJSON(gj), 4326) AS g FROM _load) s""", (name,))
        c.execute("DELETE FROM atlas.documents WHERE dataset=%s", (name,))
        c.execute("INSERT INTO atlas.documents (dataset, content_type, body) VALUES (%s,%s,%s)", (name, CONTENT_TYPES[cfg["format"]], raw))
    return len(items), checksum
