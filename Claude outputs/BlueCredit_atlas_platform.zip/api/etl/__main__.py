"""Command line for the Atlas database.

  python -m etl migrate            apply db/migrations
  python -m etl load all           load every dataset in app/registry.py from DATA_DIR
  python -m etl load hospitality   load one (or several) datasets
  python -m etl status             what's loaded, how many rows, when
  python -m etl prune-cache        delete expired API cache entries
"""
import sys
import time

from app.db import migrate, pool
from app.registry import DATASETS
from etl.loader import load


def main(argv):
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(__doc__); return 0
    cmd, args = argv[0], argv[1:]
    if cmd == "migrate":
        print("applied:", migrate() or "nothing new"); return 0
    if cmd == "load":
        migrate()
        names = list(DATASETS) if not args or args == ["all"] else args
        bad = [n for n in names if n not in DATASETS]
        if bad:
            print("unknown dataset(s):", ", ".join(bad)); return 2
        for n in names:
            t = time.time(); rows, sha = load(n)
            print(f"  {n:28s} {rows:>8,} rows  {time.time() - t:5.1f}s  {sha[:10]}")
        return 0
    if cmd == "status":
        with pool().connection() as c:
            for r in c.execute("SELECT name, access, row_count, version, loaded_at FROM atlas.datasets ORDER BY name"):
                print(f"  {r['name']:28s} {r['access']:4s} {r['row_count']:>8,}  v{r['version'] or '-':10s} {r['loaded_at']:%Y-%m-%d %H:%M}")
        return 0
    if cmd == "prune-cache":
        with pool().connection() as c:
            n = c.execute("DELETE FROM atlas.api_cache WHERE expires_at < now()").rowcount
        print("deleted", n); return 0
    print("unknown command:", cmd); return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
