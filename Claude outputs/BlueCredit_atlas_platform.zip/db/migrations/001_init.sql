-- BlueCredit Atlas database: PostGIS feature store, dataset catalog, API cache and usage log.
-- Applied by `python -m etl migrate` (or automatically when the API container starts).

CREATE EXTENSION IF NOT EXISTS postgis;
CREATE SCHEMA IF NOT EXISTS atlas;

CREATE TABLE IF NOT EXISTS atlas.schema_migrations (
    version    text PRIMARY KEY,
    applied_at timestamptz NOT NULL DEFAULT now()
);

-- One row per dataset the map uses. `meta` keeps whatever the original file format needs to be
-- rebuilt exactly (field order, CSV columns, sector groups, scenario names, ...).
CREATE TABLE IF NOT EXISTS atlas.datasets (
    name        text PRIMARY KEY,                 -- e.g. 'industrial_facilities'
    title       text NOT NULL,
    format      text NOT NULL CHECK (format IN ('rows', 'geojson', 'csv', 'topojson', 'scenarios')),
    file_name   text NOT NULL,                    -- file name the front end asks for, e.g. industrial_facilities.json
    access      text NOT NULL DEFAULT 'free' CHECK (access IN ('free', 'pro')),
    source      text,
    license     text,
    version     text,                             -- data vintage, e.g. '2024'
    refresh     text,                             -- how often it should be refreshed, e.g. 'yearly'
    meta        jsonb NOT NULL DEFAULT '{}'::jsonb,
    row_count   integer NOT NULL DEFAULT 0,
    checksum    text,                             -- sha256 of the loaded file; used as the HTTP ETag
    loaded_at   timestamptz
);

-- Every point / polygon / table row from every dataset. Geometry is NULL for rows without a location.
CREATE TABLE IF NOT EXISTS atlas.features (
    dataset   text NOT NULL REFERENCES atlas.datasets(name) ON DELETE CASCADE,
    fid       integer NOT NULL,                   -- original row order (keeps "largest first" sorting)
    geom      geometry(Geometry, 4326),
    props     jsonb NOT NULL,
    PRIMARY KEY (dataset, fid)
);
CREATE INDEX IF NOT EXISTS features_geom_idx ON atlas.features USING gist (geom);
CREATE INDEX IF NOT EXISTS features_dataset_idx ON atlas.features (dataset);

-- The original file for every dataset, served byte-for-byte to the map (so the front end needs no changes).
-- The same data is also split into atlas.features for map-area, nearby and bounding-box queries.
CREATE TABLE IF NOT EXISTS atlas.documents (
    dataset      text PRIMARY KEY REFERENCES atlas.datasets(name) ON DELETE CASCADE,
    content_type text NOT NULL,
    body         bytea NOT NULL
);

-- Cached responses from outside APIs (USGS, FEMA, ...) fetched through /api/v1/proxy.
CREATE TABLE IF NOT EXISTS atlas.api_cache (
    key          text PRIMARY KEY,               -- source + path + query
    status       integer NOT NULL,
    content_type text,
    body         bytea NOT NULL,
    fetched_at   timestamptz NOT NULL DEFAULT now(),
    expires_at   timestamptz NOT NULL
);
CREATE INDEX IF NOT EXISTS api_cache_expires_idx ON atlas.api_cache (expires_at);

-- Report activity per BlueCredit user (used for the optional monthly report limit and usage stats).
CREATE TABLE IF NOT EXISTS atlas.report_log (
    id         bigserial PRIMARY KEY,
    user_id    text NOT NULL,
    kind       text NOT NULL,                     -- site_report_open, basin_report_download, ...
    meta       jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS report_log_user_month_idx ON atlas.report_log (user_id, created_at);
