#!/usr/bin/env bash
# Nightly database backup (keeps 14 days). Cron (crontab -e as the deploy user):
#   15 3 * * *  /srv/bluecredit-atlas/deploy/backup.sh >> /var/log/atlas-backup.log 2>&1
#   30 3 * * *  cd /srv/bluecredit-atlas && docker compose run --rm loader prune-cache >/dev/null 2>&1
# Restore: docker compose exec -T db pg_restore -U atlas -d atlas --clean < backups/atlas_YYYY-MM-DD.dump
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p backups
f="backups/atlas_$(date +%F).dump"
docker compose exec -T db pg_dump -U atlas -d atlas -Fc > "$f"
find backups -name 'atlas_*.dump' -mtime +14 -delete
echo "$(date -Is) backup ok: $f ($(du -h "$f" | cut -f1))"
