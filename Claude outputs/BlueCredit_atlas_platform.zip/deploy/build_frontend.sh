#!/usr/bin/env bash
# Build the public site into dist/:
#   - copies frontend/
#   - sets the API address in index.html (API_URL, e.g. https://atlas.bluecredits.org)
#   - leaves out Pro-only data files (access='pro' in api/app/registry.py) so they are never public
# Usage: API_URL=https://atlas.bluecredits.org deploy/build_frontend.sh
set -euo pipefail
cd "$(dirname "$0")/.."
API_URL="${API_URL:-}"
rm -rf dist && mkdir dist && cp -r frontend/. dist/
if [ -n "$API_URL" ]; then
  sed -i "s#window.BC_API = window.BC_API || '';#window.BC_API = window.BC_API || '${API_URL}';#" dist/index.html
  for f in $(cd api && python3 -c "from app.registry import DATASETS; print(' '.join(v['file'] for v in DATASETS.values() if v['access']=='pro'))"); do
    rm -f "dist/data/$f" && echo "left out Pro file: data/$f"
  done
else
  echo "API_URL not set: building the static-only site (all data files included)."
fi
echo "built dist/ ($(find dist -type f | wc -l) files)"
