# BlueCredit Atlas (front end, API and database)

https://atlas.bluecredits.org. See **ARCHITECTURE.md** for how the parts fit together.

```
frontend/        the map (static site): index.html, pages/, js/, data/
  js/api.js      connects the map to the API (off when window.BC_API is empty)
api/             Atlas API (Python FastAPI)
  app/           endpoints, sign-in check, dataset registry (app/registry.py)
  etl/           loader: python -m etl [migrate | load all | load <name> | status | prune-cache]
  tests/         API tests (pytest)
db/migrations/   database schema (PostgreSQL 16 + PostGIS)
deploy/          nginx site, front-end build script, backup script
docs/            front-end notes (layers, sign-in, data sources)
docker-compose.yml, .env.example
```

## Test online with GitHub Codespaces (no Docker on your computer)

1. Put this project in a **private** GitHub repo (it includes the licensed hospitality file).
2. On the repo page, click **Code → Codespaces → Create codespace on main**.
3. Wait about 3–5 minutes. The `.devcontainer` setup installs Docker, then builds and starts the database, API and site, and loads the data.
4. Open the **Ports** tab and click the globe icon next to **8080 (Atlas)**. You get the map at a private `https://…-8080.app.github.dev` address; add `/api/docs` for the API.

Codespaces stop after 30 minutes idle; reopen the codespace to continue. A personal account gets about 60 free hours a month on a 2-core machine. Delete the codespace when you're done testing.

## Test on your own computer (Windows or Mac, with Docker Desktop)

1. Install **Docker Desktop** (docker.com/products/docker-desktop) and start it.
2. Unzip this project, for example to `Documents\GitHub\bluecredit-atlas`.
3. In that folder, copy `.env.example` to `.env`. For a local test, the defaults are fine.
4. Open a terminal in the folder (in File Explorer, type `cmd` in the address bar) and run:

```
docker compose -f docker-compose.yml -f docker-compose.local.yml up -d --build
docker compose -f docker-compose.yml -f docker-compose.local.yml run --rm loader
```

5. Open **http://localhost:8080** for the map, and **http://localhost:8080/api/docs** to try the API.

In local mode, sign-in is off and everyone is Pro, so you can test every layer and report. The first build takes a few minutes. After that, `up -d` starts everything in seconds.

| To… | Run |
|---|---|
| Stop | `docker compose -f docker-compose.yml -f docker-compose.local.yml down` |
| Stop and delete the test database | add `-v` to the stop command |
| See API logs | `docker compose logs -f api` |
| Reload data after changing a file in `frontend/data` | run the `loader` command again |

Front-end edits in `frontend/` show up on refresh; you don't need to rebuild.

## Production (Contabo VPS)

One-time setup:

```bash
# 1. Code and settings
sudo mkdir -p /srv/bluecredit-atlas && sudo chown $USER /srv/bluecredit-atlas
git clone https://github.com/BlueCredit/<atlas-repo>.git /srv/bluecredit-atlas
cd /srv/bluecredit-atlas
cp .env.example .env && nano .env            # set DB_PASSWORD (long random); check CORE_API_URL

# 2. Database + API
docker compose up -d --build
docker compose run --rm loader               # loads all 11 datasets (about 10 s)
curl -s http://127.0.0.1:8085/api/v1/health  # {"status":"ok","datasets":11,...}

# 3. Public site
API_URL=https://atlas.bluecredits.org deploy/build_frontend.sh   # builds dist/, leaves out Pro-only files
sudo cp deploy/nginx/atlas.bluecredits.org.conf /etc/nginx/sites-available/
sudo ln -s /etc/nginx/sites-available/atlas.bluecredits.org.conf /etc/nginx/sites-enabled/
sudo certbot --nginx -d atlas.bluecredits.org
sudo nginx -t && sudo systemctl reload nginx

# 4. Nightly backup and cache cleanup (see deploy/backup.sh)
crontab -e
```

Also needed:

- **DNS:** point `atlas.bluecredits.org` (A record) at the VPS. If it was a GitHub Pages CNAME, replace it.
- **bluecredits-core:** `SSO_ALLOWED_ORIGINS=atlas=https://atlas.bluecredits.org` (unchanged).

Updating:

```bash
git pull
docker compose up -d --build                         # API changes
docker compose run --rm loader load <dataset>        # data changes
API_URL=https://atlas.bluecredits.org deploy/build_frontend.sh   # front-end changes
```

**Static-only fallback:** `frontend/` still works on its own, for example on GitHub Pages, with `window.BC_API` left empty. In that mode every data file is public, including hospitality.

## Local development

```bash
docker compose up -d db                       # or any local PostGIS
export DATABASE_URL=postgresql://atlas:<pw>@localhost:5432/atlas   # publish db port 5432 locally if needed
cd api && pip install -r requirements.txt -r requirements-dev.txt
DATA_DIR=../frontend/data MIGRATIONS_DIR=../db/migrations python -m etl load all
DATA_DIR=../frontend/data MIGRATIONS_DIR=../db/migrations DEV_ALL_PRO=1 CORS_ORIGINS=http://localhost:8792 \
  uvicorn app.main:app --port 8085 --reload
# front end: serve frontend/ (e.g. python -m http.server 8792) and set window.BC_API='http://localhost:8085'
pytest -q tests
```

`DEV_ALL_PRO=1` treats every visitor as Pro. It's for local testing only; never set it on the server.
